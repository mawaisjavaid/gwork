#!/usr/bin/env bash
# =====================================================================================================================
# Google Workspace -> Wazuh sync: one-shot installer (everything up to the indexer; the Ageleia dashboard is NOT included)
#
# Run it on the host that runs the Wazuh manager. In this order it:
#   1. checks that this server can reach Google (STS, IAM Credentials, OAuth, Reports API) and PyPI
#   2. asks for the indexer URL (default https://127.0.0.1:9200), user (default admin) and password, and tests them
#   3. checks that the Google Workspace rule ids (100800-100880) do not conflict with any rule already on this manager
#   4. only if all of that passed:
#        - installs the sync service (/opt/gworkspace, python venv, systemd unit gworkspace-sync, logrotate)
#        - installs the keyless-auth certificate and the Workload Identity Federation config in /opt/gworkspace/certs
#        - runs the sync once in dry-run mode: certificate -> Google token -> signJwt -> delegated Reports API token
#        - installs the Wazuh rules and the <localfile> block, validates them with wazuh-analysisd -t (rolls back on error)
#        - updates the indexer's GeoIP database (DB-IP City Lite, CC BY 4.0) so source IPs get the right country
#        - starts the service, waits until the events show up in wazuh-alerts-*, and prints what arrived (apps, countries, newest events)
#
# Authentication is keyless: no service account key exists. The client certificate (X.509) is exchanged for a Google
# token through Workload Identity Federation, Google signs the delegated-admin JWT (IAM Credentials signJwt), and the
# JWT is exchanged for a read-only Reports API token (domain-wide delegation, admin.reports.audit.readonly).
#
# NOTE: this script contains the client certificate AND its private key (client.key). Treat the file like a credential:
# keep it mode 0700, do not share or commit it, and delete it after the install.
#
# Usage:   sudo bash install-gworkspace-sync.sh [--yes] [--insecure] [--skip-geoip] [--cert-dir DIR] [--uninstall] [--purge]
#   --yes         do not ask before restarting wazuh-manager
#   --insecure    do not verify the indexer's TLS certificate (also INDEXER_INSECURE=1). Without it the script verifies the
#                 certificate and, if its host name does not match the URL (typical for https://127.0.0.1:9200), falls back
#                 to skipping verification for the indexer only, with a warning.
#   --skip-geoip  do not update the indexer's GeoIP database (step "GeoIP")
#   --cert-dir D  use client.crt, client.key and ca.crt from directory D instead of the ones embedded in this script
#   --uninstall   stop and remove the service, rules, localfile block and logrotate policy (keeps data and certificates)
#   --purge       with --uninstall: also delete /opt/gworkspace (certificates included) and /etc/gworkspace-sync
# Non-interactive: export INDEXER_PASSWORD (optionally INDEXER_URL, INDEXER_USER, INDEXER_CA, USED_RULE_IDS_FILE,
#   GWORKSPACE_SERVICE_ACCOUNT, GWORKSPACE_DELEGATED_ADMIN, GWORKSPACE_CUSTOMER_ID, GWORKSPACE_DOMAINS, GWORKSPACE_CLIENT_ID).
# =====================================================================================================================
set -euo pipefail

YES=0; UNINSTALL=0; PURGE=0; INSECURE=${INDEXER_INSECURE:-0}; CERT_SRC=""; SKIP_GEOIP=${SKIP_GEOIP:-0}
while [ $# -gt 0 ]; do
  case "$1" in
    --yes|-y) YES=1 ;; --insecure|-k) INSECURE=1 ;; --skip-geoip) SKIP_GEOIP=1 ;; --uninstall) UNINSTALL=1 ;; --purge) PURGE=1 ;;
    --cert-dir) shift; CERT_SRC=${1:-}; [ -n "$CERT_SRC" ] || { echo "--cert-dir needs a directory" >&2; exit 2; } ;;
    -h|--help) sed -n 2,40p "$0"; exit 0 ;;
    *) echo "unknown option: $1" >&2; exit 2 ;;
  esac
  shift
done

SYNC_DIR=/opt/gworkspace
ENV_DIR=/etc/gworkspace-sync
CERT_DIR=$SYNC_DIR/certs        # the certificate, its key and the WIF config live under /opt/gworkspace
VENV=$SYNC_DIR/venv
UNIT=/etc/systemd/system/gworkspace-sync.service
RULES_DIR=/var/ossec/etc/rules
OSSEC_CONF=/var/ossec/etc/ossec.conf
RULE_FILE=gworkspace_rules.xml
LOCALFILE=gworkspace_activities.jsonl
STAMP=$(date +%Y%m%d-%H%M%S)
GOOGLE_HOSTS="sts.mtls.googleapis.com iamcredentials.googleapis.com oauth2.googleapis.com admin.googleapis.com"
GEOIP_DIR=/usr/share/wazuh-indexer/modules/ingest-geoip
GEOIP_DB=$GEOIP_DIR/GeoLite2-City.mmdb

if [ -t 1 ]; then B=$'\e[1m'; G=$'\e[32m'; Y=$'\e[33m'; R=$'\e[31m'; N=$'\e[0m'; else B=; G=; Y=; R=; N=; fi
step() { echo; echo "${B}==> $*${N}"; }
ok()   { echo "  ${G}ok${N}  $*"; }
warn() { echo "  ${Y}warn${N} $*"; }
die()  { echo "  ${R}error${N} $*" >&2; exit 1; }

WORK=$(mktemp -d); chmod 700 "$WORK"
trap 'rm -rf "$WORK"' EXIT

[ "$(id -u)" -eq 0 ] || die "run as root (sudo bash $0)"
command -v systemctl >/dev/null || die "systemd is required"
command -v curl >/dev/null || die "curl is required"
command -v python3 >/dev/null || die "python3 is required"
python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)' || die "python3 >= 3.8 is required"
[ -x /var/ossec/bin/wazuh-control ] || die "Wazuh manager not found in /var/ossec (run this on the Wazuh manager host)"

# ------------------------------------------------------------------------------------------------ uninstall
if [ "$UNINSTALL" -eq 1 ]; then
  step "Uninstalling the Google Workspace sync"
  systemctl disable --now gworkspace-sync 2>/dev/null || true
  rm -f "$UNIT"; systemctl daemon-reload
  rm -f "$RULES_DIR/$RULE_FILE" /etc/logrotate.d/gworkspace-sync
  python3 - "$OSSEC_CONF" "$STAMP" <<'PY'
import re, shutil, sys
p, stamp = sys.argv[1], sys.argv[2]
s = open(p).read()
n = re.sub(r"\n[ \t]*<localfile>\s*<log_format>json</log_format>\s*<location>/opt/gworkspace/gworkspace_activities\.jsonl</location>\s*</localfile>[ \t]*", "", s)
if n != s:
    shutil.copy(p, p + ".bak-gworkspace-" + stamp); open(p, "w").write(n)
PY
  if [ "$PURGE" -eq 1 ]; then rm -rf "$SYNC_DIR" "$ENV_DIR"; ok "removed $SYNC_DIR and $ENV_DIR (certificates included)"
  else warn "kept $SYNC_DIR and $ENV_DIR (use --purge to delete, certificates included)"; fi
  ok "removed. Restart wazuh-manager to unload the rules: systemctl restart wazuh-manager"
  exit 0
fi

# ------------------------------------------------------------------------------------------------ 1. network
step "1/4  Checking that this server can reach Google and PyPI (HTTPS, port 443)"
net_fail=0
probe() {  # probe host  -> any HTTP answer (even 404) proves DNS, TCP, TLS and the egress path work
  local host=$1 code rc why
  if [ -z "${HTTPS_PROXY:-}${https_proxy:-}" ] && command -v getent >/dev/null && ! getent hosts "$host" >/dev/null 2>&1; then
    echo "  ${R}fail${N} $host: DNS does not resolve from this server (check /etc/resolv.conf, VPC DNS settings or a private DNS zone)"; net_fail=1; return
  fi
  code=$(curl -sS -o /dev/null -w '%{http_code}' --connect-timeout 10 -m 25 "https://$host/" 2>"$WORK/net.err") && rc=0 || rc=$?
  if [ "$rc" -ne 0 ]; then
    case "$rc" in
      6)  why="DNS: the name does not resolve." ;;
      7)  why="the connection was refused or reset on port 443." ;;
      28) why="timed out: typical of a firewall dropping outbound traffic (Security Group outbound TCP 443, Network ACL, route/NAT, proxy)." ;;
      35|51|58|60|77) why="TLS handshake/certificate failed: a TLS-inspecting proxy probably re-signs the traffic; install its CA on this server." ;;
      5|56) why="the proxy refused or dropped the connection (check HTTPS_PROXY / NO_PROXY)." ;;
      *)  why="curl exit code $rc." ;;
    esac
    echo "  ${R}fail${N} $host: $why"; net_fail=1
  else
    ok "$host (HTTP $code)"
  fi
}
for h in $GOOGLE_HOSTS; do probe "$h"; done
if [ "$SKIP_GEOIP" -ne 1 ] && [ -d "$GEOIP_DIR" ]; then probe download.db-ip.com; fi
if [ -x "$VENV/bin/python" ] && "$VENV/bin/python" -c 'import requests, google.auth, cryptography, OpenSSL' 2>/dev/null; then
  ok "python packages already installed in $VENV: PyPI is not needed"
else
  for h in pypi.org files.pythonhosted.org; do probe "$h"; done
fi
[ "$net_fail" -eq 0 ] || die "this server cannot reach everything the sync needs (see above). The sync only talks to those hosts over HTTPS 443.
        Ask the network/cloud admin to allow outbound access, then run this script again.
        Quick test:  curl -v https://sts.mtls.googleapis.com/   (any HTTP answer, even 404, means the path is open)"

# ------------------------------------------------------------------------------------------------ 2. indexer
step "2/4  Wazuh indexer"
if [ -t 0 ]; then TTY=/dev/stdin; elif { : </dev/tty; } 2>/dev/null; then TTY=/dev/tty; else TTY=""; fi
ask_secret() {  # ask_secret VAR "prompt"
  local var=$1 prompt=$2 v=""
  if [ -n "${!var:-}" ]; then return; fi
  [ -n "$TTY" ] || die "$var is not set and there is no terminal to ask on (export $var=... and run again)"
  while [ -z "$v" ]; do read -rsp "$prompt: " v < "$TTY"; echo >&2; done
  printf -v "$var" '%s' "$v"
}
ask() {  # ask VAR "prompt" default
  local var=$1 prompt=$2 def=$3 v=""
  if [ -n "${!var:-}" ]; then return; fi
  if [ -n "$TTY" ]; then read -rp "$prompt [$def]: " v < "$TTY"; fi
  printf -v "$var" '%s' "${v:-$def}"
}
INDEXER_PASSWORD=${INDEXER_PASSWORD:-}; INDEXER_URL=${INDEXER_URL:-}; INDEXER_USER=${INDEXER_USER:-}
ask INDEXER_URL "Wazuh indexer URL" "https://127.0.0.1:9200"
ask INDEXER_USER "Wazuh indexer user" "admin"
ask_secret INDEXER_PASSWORD "Wazuh indexer password for '$INDEXER_USER'"
INDEXER_URL=${INDEXER_URL%/}
case "$INDEXER_URL" in http://*|https://*) ;; *) INDEXER_URL="https://$INDEXER_URL" ;; esac
INDEXER_CA=${INDEXER_CA:-/etc/wazuh-indexer/certs/root-ca.pem}
if [ "$INSECURE" -eq 1 ]; then CA_OPT=(-k); elif [ -r "$INDEXER_CA" ]; then CA_OPT=(--cacert "$INDEXER_CA"); else CA_OPT=(-k); fi

# curl with the password kept off the command line (it would show in ps)
cfg_escape() { local s=$1; s=${s//\\/\\\\}; s=${s//\"/\\\"}; printf '%s' "$s"; }
ix() { curl -sS "${CA_OPT[@]}" -K <(printf 'user = "%s"\n' "$(cfg_escape "$INDEXER_USER:$INDEXER_PASSWORD")") "$@"; }

code=$(ix -o /dev/null -w '%{http_code}' -m 20 "$INDEXER_URL/" 2>"$WORK/ix.err") && rc=0 || rc=$?
if [ "$rc" -ne 0 ] && [ "${CA_OPT[0]}" != -k ]; then
  case "$rc" in
    51|58|60|77)   # certificate does not match the host name / unknown CA: expected for https://127.0.0.1 with a node-name certificate
      warn "the indexer's TLS certificate could not be verified ($(tr -d '\n' <"$WORK/ix.err" | cut -c1-110))"
      warn "continuing WITHOUT certificate verification for the indexer only (credentials go to $INDEXER_URL; use --insecure to skip this probe)"
      CA_OPT=(-k)
      code=$(ix -o /dev/null -w '%{http_code}' -m 20 "$INDEXER_URL/" 2>"$WORK/ix.err") && rc=0 || rc=$? ;;
  esac
fi
[ "$rc" -eq 0 ] || code=000
case "$code" in
  200) ok "indexer reachable at $INDEXER_URL, credentials accepted" ;;
  401) die "the indexer rejected the user/password" ;;
  *) die "the indexer at $INDEXER_URL did not answer (HTTP $code, curl exit $rc): $(tr -d '\n' <"$WORK/ix.err" 2>/dev/null | cut -c1-200)" ;;
esac
ix -m 20 "$INDEXER_URL/_cat/indices/wazuh-alerts-*?h=index" | head -1 | grep -q wazuh-alerts && ok "wazuh-alerts-* indices exist" \
  || warn "no wazuh-alerts-* index yet (it is created when the first alert arrives)"

# ------------------------------------------------------------------------------------------------ 3. rule conflicts
step "3/4  Checking the rule ids against the rules already on this manager"
cat > "$WORK/gworkspace_rules.xml" <<'__EOF_rules__'
@@FILE:src/rules/gworkspace_rules.xml@@
__EOF_rules__
cat > "$WORK/check_rules.py" <<'__EOF_check_rules__'
@@FILE:src/check_rules.py@@
__EOF_check_rules__
RULE_SCAN_DIRS=("$RULES_DIR" /var/ossec/ruleset/rules)
# extra rule directories declared in ossec.conf (<rule_dir>), relative to /var/ossec
while IFS= read -r d; do
  d=${d//[[:space:]]/}; [ -n "$d" ] || continue
  case "$d" in /*) ;; *) d="/var/ossec/$d" ;; esac
  [ -d "$d" ] && RULE_SCAN_DIRS+=("$d")
done < <(grep -o '<rule_dir[^>]*>[^<]*</rule_dir>' "$OSSEC_CONF" 2>/dev/null | sed 's/<[^>]*>//g' || true)
mapfile -t RULE_SCAN_DIRS < <(printf '%s\n' "${RULE_SCAN_DIRS[@]}" | awk '!seen[$0]++')
USED_OPT=(); if [ -n "${USED_RULE_IDS_FILE:-}" ] && [ -r "$USED_RULE_IDS_FILE" ]; then USED_OPT=(--used-ids "$USED_RULE_IDS_FILE"); fi
if python3 -I "$WORK/check_rules.py" "$WORK/gworkspace_rules.xml" "$RULE_FILE" "${RULE_SCAN_DIRS[@]}" "${USED_OPT[@]}"; then
  ok "the Google Workspace rules do not conflict with existing rules"
else
  die "rule id conflict: nothing was installed. Resolve it (renumber the Workspace rules, or retire the other rule) and run this script again."
fi

# ------------------------------------------------------------------------------------------------ 4. install
step "4/4  Installing the sync service"
GRP=root; getent group wazuh >/dev/null && GRP=wazuh
write_file() {  # write_file path mode owner:group  (content on stdin); keeps a .bak-STAMP copy of a different existing file
  local path=$1 mode=$2 own=$3 tmp; tmp=$(mktemp "$WORK/wf.XXXXXX")
  cat > "$tmp"
  if [ -e "$path" ] && ! cmp -s "$tmp" "$path"; then cp -p "$path" "$path.bak-$STAMP"; fi
  install -m "$mode" -o "${own%%:*}" -g "${own##*:}" "$tmp" "$path"; rm -f "$tmp"
}
install -d -m 2750 -o root -g "$GRP" "$SYNC_DIR"
install -d -m 0750 -o root -g root "$ENV_DIR" "$CERT_DIR"   # certs dir: root only (the key must not be group-readable)

# --- certificate (keyless authentication)
if [ -n "$CERT_SRC" ]; then
  for f in client.crt client.key ca.crt; do [ -r "$CERT_SRC/$f" ] || die "$CERT_SRC/$f not found (--cert-dir needs client.crt, client.key and ca.crt)"; done
  install -m 0644 -o root -g root "$CERT_SRC/client.crt" "$CERT_DIR/client.crt"
  install -m 0600 -o root -g root "$CERT_SRC/client.key" "$CERT_DIR/client.key"
  install -m 0644 -o root -g root "$CERT_SRC/ca.crt" "$CERT_DIR/ca.crt"
  CERT_FROM="$CERT_SRC"
else
  write_file "$CERT_DIR/client.crt" 0644 root:root <<'__EOF_client_crt__'
@@FILE:src/certs/client.crt@@
__EOF_client_crt__
  write_file "$CERT_DIR/client.key" 0600 root:root <<'__EOF_client_key__'
@@FILE:src/certs/client.key@@
__EOF_client_key__
  write_file "$CERT_DIR/ca.crt" 0644 root:root <<'__EOF_ca_crt__'
@@FILE:src/certs/ca.crt@@
__EOF_ca_crt__
  CERT_FROM="the certificate embedded in this script"
fi
if command -v openssl >/dev/null; then
  openssl x509 -in "$CERT_DIR/client.crt" -noout >/dev/null 2>&1 || die "$CERT_DIR/client.crt is not a valid certificate"
  [ "$(openssl x509 -in "$CERT_DIR/client.crt" -noout -pubkey 2>/dev/null)" = "$(openssl pkey -in "$CERT_DIR/client.key" -pubout 2>/dev/null)" ] \
    || die "the private key in $CERT_DIR/client.key does not match client.crt"
  openssl x509 -in "$CERT_DIR/client.crt" -noout -checkend 0 >/dev/null || die "the client certificate has expired ($(openssl x509 -in "$CERT_DIR/client.crt" -noout -enddate))"
  if openssl x509 -in "$CERT_DIR/client.crt" -noout -checkend $((30*86400)) >/dev/null; then ok "client certificate installed from $CERT_FROM, $(openssl x509 -in "$CERT_DIR/client.crt" -noout -enddate)"
  else warn "the client certificate expires within 30 days: $(openssl x509 -in "$CERT_DIR/client.crt" -noout -enddate)"; fi
else
  warn "openssl not found: the certificate and key were installed but not validated"
  ok "client certificate installed from $CERT_FROM"
fi
write_file "$CERT_DIR/wif-credential-config.json" 0600 root:root <<'__EOF_wif__'
@@FILE:src/wif-credential-config.json@@
__EOF_wif__
write_file "$CERT_DIR/certificate_config.json" 0600 root:root <<'__EOF_certcfg__'
@@FILE:src/certificate_config.json@@
__EOF_certcfg__
ok "$CERT_DIR/wif-credential-config.json and certificate_config.json (Workload Identity Federation, X.509 provider)"

# --- settings (env file; no secrets)
cat > "$WORK/env.defaults" <<'__EOF_env_defaults__'
@@FILE:src/env.defaults@@
__EOF_env_defaults__
envdef() { grep -m1 "^$1=" "$WORK/env.defaults" | cut -d= -f2- || true; }
if [ -e "$ENV_DIR/env" ]; then
  cp -p "$ENV_DIR/env" "$ENV_DIR/env.bak-$STAMP"
  for kv in "GWORKSPACE_WIF_CONFIG=$CERT_DIR/wif-credential-config.json" "GWORKSPACE_CLIENT_CERT=$CERT_DIR/client.crt"; do
    k=${kv%%=*}; if grep -q "^$k=" "$ENV_DIR/env"; then sed -i "s|^$k=.*|$kv|" "$ENV_DIR/env"; else printf '%s\n' "$kv" >> "$ENV_DIR/env"; fi
  done
  ok "kept your existing $ENV_DIR/env (certificate paths set to $CERT_DIR)"
else
  echo "  Google Workspace settings (press Enter to accept the value in brackets)"
  GWORKSPACE_SERVICE_ACCOUNT=${GWORKSPACE_SERVICE_ACCOUNT:-}; GWORKSPACE_DELEGATED_ADMIN=${GWORKSPACE_DELEGATED_ADMIN:-}
  GWORKSPACE_CUSTOMER_ID=${GWORKSPACE_CUSTOMER_ID:-}; GWORKSPACE_DOMAINS=${GWORKSPACE_DOMAINS:-}; GWORKSPACE_CLIENT_ID=${GWORKSPACE_CLIENT_ID:-}
  ask GWORKSPACE_SERVICE_ACCOUNT "  Service account (signs the JWT)" "$(envdef GWORKSPACE_SERVICE_ACCOUNT)"
  ask GWORKSPACE_DELEGATED_ADMIN "  Delegated super admin to impersonate" "$(envdef GWORKSPACE_DELEGATED_ADMIN)"
  ask GWORKSPACE_CUSTOMER_ID "  Workspace customer id" "$(envdef GWORKSPACE_CUSTOMER_ID)"
  ask GWORKSPACE_DOMAINS "  Workspace domain(s), comma separated" "$(envdef GWORKSPACE_DOMAINS)"
  ask GWORKSPACE_CLIENT_ID "  Service account client id (domain-wide delegation)" "$(envdef GWORKSPACE_CLIENT_ID)"
  case "$GWORKSPACE_SERVICE_ACCOUNT$GWORKSPACE_DELEGATED_ADMIN" in *[\"\'\ \$\`\\]*) die "the settings must not contain spaces, quotes, \$ or backslashes" ;; esac
  write_file "$ENV_DIR/env" 0600 root:root <<EOF
# Google Workspace sync settings (no secrets here; the client key is in $CERT_DIR)
GWORKSPACE_SERVICE_ACCOUNT=$GWORKSPACE_SERVICE_ACCOUNT
GWORKSPACE_DELEGATED_ADMIN=$GWORKSPACE_DELEGATED_ADMIN
GWORKSPACE_CUSTOMER_ID=$GWORKSPACE_CUSTOMER_ID
GWORKSPACE_SYNC_INTERVAL=$(envdef GWORKSPACE_SYNC_INTERVAL)
GWORKSPACE_CLIENT_ID=$GWORKSPACE_CLIENT_ID
GWORKSPACE_DOMAINS=$GWORKSPACE_DOMAINS
GWORKSPACE_WIF_CONFIG=$CERT_DIR/wif-credential-config.json
GWORKSPACE_CLIENT_CERT=$CERT_DIR/client.crt
GWORKSPACE_FIRST_RUN_LOOKBACK_HOURS=$(envdef GWORKSPACE_FIRST_RUN_LOOKBACK_HOURS)
EOF
  ok "$ENV_DIR/env"
fi

# --- sync program, python environment, unit, logrotate
write_file "$SYNC_DIR/gworkspace_sync.py" 0750 root:$GRP <<'__EOF_gworkspace_sync_py__'
@@FILE:src/gworkspace_sync.py@@
__EOF_gworkspace_sync_py__
ok "$SYNC_DIR/gworkspace_sync.py"
if [ -x "$VENV/bin/python" ] && "$VENV/bin/python" -c 'import requests, google.auth, cryptography, OpenSSL' 2>/dev/null; then
  ok "python environment $VENV is already complete"
else
  python3 -m venv "$VENV" 2>"$WORK/venv.err" || die "cannot create the python environment (on Debian/Ubuntu: apt install python3-venv): $(tr -d '\n' <"$WORK/venv.err" | cut -c1-160)"
  cat > "$WORK/requirements.txt" <<'__EOF_requirements__'
@@FILE:src/requirements.txt@@
__EOF_requirements__
  "$VENV/bin/python" -m pip install --quiet --disable-pip-version-check -r "$WORK/requirements.txt" 2>"$WORK/pip.err" \
    || die "pip install failed: $(tail -3 "$WORK/pip.err" | tr -d '\n' | cut -c1-240)"
  ok "python environment $VENV (requests, google-auth, cryptography, pyOpenSSL)"
fi
write_file "$UNIT" 0644 root:root <<'__EOF_unit__'
@@FILE:src/gworkspace-sync.service@@
__EOF_unit__
write_file /etc/logrotate.d/gworkspace-sync 0644 root:root <<'__EOF_logrotate__'
@@FILE:src/gworkspace-sync.logrotate@@
__EOF_logrotate__
ok "$UNIT and /etc/logrotate.d/gworkspace-sync"

# --- authentication test before anything touches Wazuh
step "Testing the keyless authentication (reads the audit log once, writes nothing)"
if (set -a; . "$ENV_DIR/env"; set +a; cd "$SYNC_DIR"; "$VENV/bin/python" -u "$SYNC_DIR/gworkspace_sync.py" --dry-run) >"$WORK/auth.log" 2>&1; then
  grep -F '[dry-run]' "$WORK/auth.log" | cut -c1-200 | sed 's/^/        /'
  ok "certificate -> Google token -> signJwt -> delegated Reports API token all worked"
else
  tail -15 "$WORK/auth.log" >&2
  die "the authentication test failed (log above). Typical causes: the client certificate is not enrolled in the Workload Identity pool, the service account lacks 'Service Account Token Creator' on itself, domain-wide delegation of the client id is missing, or the delegated admin is wrong. Wazuh was not changed; fix it and run this script again."
fi

# ------------------------------------------------------------------------------------------------ geoip
step "GeoIP: updating the indexer's country database"
cat > "$WORK/patch_mmdb.py" <<'__EOF_patch_mmdb__'
@@FILE:src/patch_mmdb.py@@
__EOF_patch_mmdb__
geo_sim() {  # country the indexer's own geoip processor gives for an IP (empty if the processor fails)
  ix -m 20 -X POST -H 'Content-Type: application/json' "$INDEXER_URL/_ingest/pipeline/_simulate" \
    -d '{"pipeline":{"processors":[{"geoip":{"field":"ip","target_field":"g","database_file":"GeoLite2-City.mmdb"}}]},"docs":[{"_source":{"ip":"'"$1"'"}}]}' 2>/dev/null \
    | python3 -c 'import json,sys
try: print(json.load(sys.stdin)["docs"][0]["doc"]["_source"]["g"]["country_name"])
except Exception: print("")' || true
}
wait_indexer() { local i; for i in $(seq 1 45); do [ "$(ix -m 10 -o /dev/null -w '%{http_code}' "$INDEXER_URL/_cluster/health" 2>/dev/null || true)" = 200 ] && return 0; sleep 4; done; return 1; }
if [ "$SKIP_GEOIP" -eq 1 ]; then warn "skipped (--skip-geoip): country names come from the database the indexer shipped with, which can be outdated"
elif [ ! -d "$GEOIP_DIR" ]; then warn "the indexer is not on this host ($GEOIP_DIR not found): update GeoLite2-City.mmdb on the indexer host, country names may be outdated until then"
elif tail -c 4096 "$GEOIP_DB" 2>/dev/null | grep -aq 'DB-IP.com'; then ok "the GeoIP database is already the DB-IP City Lite build"
else
  if [ "$YES" -eq 1 ] || [ -z "$TTY" ]; then a=y; else
    echo "  The database shipped with the indexer can place IPs in the wrong country (a Pakistani ISP range showed up as South Africa)."
    echo "  This replaces it with DB-IP City Lite (free, CC BY 4.0, https://db-ip.com) and restarts wazuh-indexer once (about a minute; alerts are retried)."
    read -rp "  Update the GeoIP database now? [Y/n] " a < "$TTY"; fi
  if [ "${a:-y}" = n ] || [ "${a:-y}" = N ]; then warn "skipped by choice"; else
    got=0
    for m in "$(date +%Y-%m)" "$(date -d '-1 month' +%Y-%m 2>/dev/null || date -v-1m +%Y-%m)"; do
      if curl -sfL --connect-timeout 15 -m 600 -o "$WORK/city.mmdb.gz" "https://download.db-ip.com/free/dbip-city-lite-$m.mmdb.gz"; then got=1; break; fi
    done
    if [ "$got" -ne 1 ] || ! gzip -t "$WORK/city.mmdb.gz" 2>/dev/null; then warn "could not download the DB-IP database; keeping the current one"
    else
      gunzip -f "$WORK/city.mmdb.gz"
      if [ "$(stat -c %s "$WORK/city.mmdb")" -lt 50000000 ]; then warn "the downloaded database looks too small; keeping the current one"
      elif ! python3 -I "$WORK/patch_mmdb.py" "$WORK/city.mmdb" "$WORK/city-patched.mmdb" >/dev/null; then warn "the downloaded database has an unexpected format; keeping the current one"
      else
        cp -p "$GEOIP_DB" "$GEOIP_DB.orig-$STAMP"
        OWN=$(stat -c %U:%G "$GEOIP_DB"); install -m 0640 -o "${OWN%%:*}" -g "${OWN##*:}" "$WORK/city-patched.mmdb" "$GEOIP_DB"
        systemctl restart wazuh-indexer
        if wait_indexer && [ -n "$(geo_sim 8.8.8.8)" ]; then
          ok "GeoIP database updated (backup: $GEOIP_DB.orig-$STAMP); 8.8.8.8 -> $(geo_sim 8.8.8.8)"
          echo "        IP geolocation by DB-IP (https://db-ip.com), CC BY 4.0"
        else
          warn "the indexer did not accept the new database: restoring the original"
          cp -p "$GEOIP_DB.orig-$STAMP" "$GEOIP_DB"; systemctl restart wazuh-indexer; wait_indexer || warn "wazuh-indexer is slow to come back: check 'systemctl status wazuh-indexer'"
        fi
      fi
    fi
  fi
fi

# ------------------------------------------------------------------------------------------------ wazuh
step "Installing the Wazuh rules and log source"
RULES_BAK=$(mktemp -d "$WORK/bak.XXXXXX")
[ -e "$RULES_DIR/$RULE_FILE" ] && cp -p "$RULES_DIR/$RULE_FILE" "$RULES_BAK/$RULE_FILE"
cp -p "$OSSEC_CONF" "$RULES_BAK/ossec.conf"
write_file "$RULES_DIR/$RULE_FILE" 0660 root:wazuh < "$WORK/gworkspace_rules.xml"
ok "rules 100800-100880 in $RULES_DIR/$RULE_FILE"

python3 - "$OSSEC_CONF" "$SYNC_DIR/$LOCALFILE" <<'PY'
import sys
p, loc = sys.argv[1], sys.argv[2]
s = open(p).read()
if loc in s:
    print("  localfile block already present")
else:
    add = "\n  <localfile>\n    <log_format>json</log_format>\n    <location>%s</location>\n  </localfile>\n" % loc
    i = s.rindex("</ossec_config>")
    open(p, "w").write(s[:i].rstrip("\n") + "\n" + add + "\n" + s[i:])
    print("  added the localfile block to " + p)
PY

if /var/ossec/bin/wazuh-analysisd -t >"$WORK/analysisd.log" 2>&1; then ok "Wazuh accepts the rules and ossec.conf"
else
  cat "$WORK/analysisd.log" >&2
  if [ -e "$RULES_BAK/$RULE_FILE" ]; then cp -p "$RULES_BAK/$RULE_FILE" "$RULES_DIR/$RULE_FILE"; else rm -f "$RULES_DIR/$RULE_FILE"; fi
  cp -p "$RULES_BAK/ossec.conf" "$OSSEC_CONF"
  die "Wazuh rejected the configuration; the rules and ossec.conf were put back as they were (the sync service is installed but not started)"
fi

if [ "$YES" -eq 1 ] || [ -z "$TTY" ]; then a=y; else read -rp "Restart wazuh-manager now (needed to load the rules and the log source)? [Y/n] " a < "$TTY"; fi
if [ "${a:-y}" != n ] && [ "${a:-y}" != N ]; then systemctl restart wazuh-manager && ok "wazuh-manager restarted"
else warn "not restarted: run 'systemctl restart wazuh-manager' before the events can be rated"; fi

# ------------------------------------------------------------------------------------------------ start
step "Starting the sync service"
systemctl daemon-reload
systemctl enable gworkspace-sync >/dev/null 2>&1 || true
systemctl restart gworkspace-sync
sleep 3
systemctl is-active --quiet gworkspace-sync && ok "gworkspace-sync is running" || { journalctl -u gworkspace-sync -n 20 --no-pager >&2; die "gworkspace-sync did not start"; }

step "Waiting for the first events to reach wazuh-alerts-* (up to 6 minutes)"
IXQ() { ix -m 30 -X POST -H 'Content-Type: application/json' "$INDEXER_URL/wazuh-alerts-*/_search?ignore_unavailable=true" -d "$1" 2>/dev/null || echo '{}'; }
EV_Q='{"term":{"data.type":"gws_activity"}}'
count_events() { IXQ '{"size":0,"track_total_hits":true,"query":{"bool":{"filter":[{"term":{"data.integration":"google-workspace"}},'"$EV_Q"']}}}' \
  | python3 -c 'import json,sys
try: print(json.load(sys.stdin)["hits"]["total"]["value"])
except Exception: print(0)'; }
n=0; for i in $(seq 1 36); do
  n=$(count_events)
  [ "${n:-0}" -gt 0 ] 2>/dev/null && break
  printf '.'; sleep 10
done; echo
cat > "$WORK/report.py" <<'__EOF_report__'
import json, sys
ev, hb = json.load(open(sys.argv[1])), json.load(open(sys.argv[2]))
tot = ev["hits"]["total"]["value"]
ag = ev.get("aggregations", {})
apps = [(b["key"], b["doc_count"]) for b in ag.get("apps", {}).get("buckets", [])]
ctry = [(b["key"], b["doc_count"]) for b in ag.get("countries", {}).get("buckets", [])]
withip = ag.get("withip", {}).get("doc_count", 0); withgeo = ag.get("withgeo", {}).get("doc_count", 0)
print("  Google Workspace events in wazuh-alerts-*: %d" % tot)
print("  by application : " + ", ".join("%s=%d" % a for a in apps))
print("  with source IP : %d   with country: %d   countries: %s" % (withip, withgeo, ", ".join("%s=%d" % c for c in ctry) or "none"))
h = hb["hits"]["hits"]
if h:
    s = h[0]["_source"].get("data", {}).get("sync", {})
    print("  sync heartbeat : status=%s new=%s requests=%s failed_apps=%s (%s)" % (s.get("status"), s.get("new_events"), s.get("requests"), s.get("failed_apps"), h[0]["_source"].get("timestamp", "")[:19]))
print("  newest events  :")
for x in ev["hits"]["hits"]:
    d = x["_source"].get("data", {}).get("gws", {})
    g = x["_source"].get("GeoLocation", {})
    print("    %s  %-12s %-28s %-34s %-18s %s" % (x["_source"].get("timestamp", "")[:19], d.get("application", ""), d.get("event_name", "")[:28],
          (d.get("actor", {}) or {}).get("email", "")[:34], d.get("ip_address", "")[:18], g.get("country_name", "")))
# exit code: 0 events found, 3 events but IPs without countries
sys.exit(3 if withip and not withgeo else 0)
__EOF_report__
RESULT=fail
if [ "${n:-0}" -gt 0 ] 2>/dev/null; then
  IXQ '{"size":5,"sort":[{"timestamp":"desc"}],"track_total_hits":true,"_source":["timestamp","data.gws.application","data.gws.event_name","data.gws.actor.email","data.gws.ip_address","GeoLocation.country_name"],"query":{"bool":{"filter":[{"term":{"data.integration":"google-workspace"}},'"$EV_Q"']}},"aggs":{"apps":{"terms":{"field":"data.gws.application","size":25}},"countries":{"terms":{"field":"GeoLocation.country_name","size":10}},"withip":{"filter":{"exists":{"field":"data.gws.ip_address"}}},"withgeo":{"filter":{"exists":{"field":"GeoLocation.country_name"}}}}}' > "$WORK/ev.json"
  IXQ '{"size":1,"sort":[{"timestamp":"desc"}],"query":{"bool":{"filter":[{"term":{"data.integration":"google-workspace"}},{"term":{"data.type":"athena_gws_sync_heartbeat"}}]}}}' > "$WORK/hb.json"
  python3 "$WORK/report.py" "$WORK/ev.json" "$WORK/hb.json" && rc=0 || rc=$?
  if [ "$rc" -eq 0 ]; then RESULT=pass; ok "Google Workspace events are in the indexer, with countries"
  elif [ "$rc" -eq 3 ]; then RESULT=nogeo; warn "events are in the indexer but none has a country yet. IPs are geolocated by the indexer's pipeline: check that Filebeat's wazuh pipeline is loaded (filebeat setup --pipelines) and that the GeoIP step above succeeded"
  else warn "events are in the indexer, but the summary could not be read"; RESULT=pass; fi
else
  warn "no Google Workspace events in wazuh-alerts-* after 6 minutes. Diagnosis:"
  echo "        service        : $(systemctl is-active gworkspace-sync)"
  echo "        buffer lines   : $(wc -l < "$SYNC_DIR/$LOCALFILE" 2>/dev/null || echo 'file missing')  ($SYNC_DIR/$LOCALFILE)"
  echo "        logcollector   : $(grep -c "$SYNC_DIR/$LOCALFILE" /var/ossec/logs/ossec.log 2>/dev/null || echo 0) ossec.log line(s) mention the file"
  echo "        alerts.json    : $(grep -c '"integration":"google-workspace"' /var/ossec/logs/alerts/alerts.json 2>/dev/null || echo 0) google-workspace alert(s) written by the manager"
  echo "        last journal   :"; journalctl -u gworkspace-sync -n 6 --no-pager 2>/dev/null | cut -c1-200 | sed 's/^/          /'
  echo "        (no alerts.json hits = the manager is not rating the file; alerts there but not in the indexer = Filebeat/indexer problem)"
fi

cat <<EOF

${B}Done.${N}  result: ${RESULT}
  Service        systemctl status gworkspace-sync     journalctl -u gworkspace-sync -f
  Settings       $ENV_DIR/env  (then: systemctl restart gworkspace-sync)
  Certificate    $CERT_DIR  (client.crt, client.key, ca.crt, certificate_config.json, wif-credential-config.json)
  Rules          $RULES_DIR/$RULE_FILE  (100800-100880)
  Data buffer    $SYNC_DIR/$LOCALFILE  (rotated daily; real data lives in wazuh-alerts-*)
The first run back-fills the last 168 hours; the Reports API can lag events by minutes to a few hours.
This installer contains the client private key: delete it from this host once you are done (shred -u install-gworkspace-sync.sh).
EOF
[ "$RESULT" = fail ] && exit 1
exit 0

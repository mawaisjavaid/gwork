# Google Workspace sync installer

`install-gworkspace-sync.sh` is one self-contained script (built by `python3 build.py` from `src/` and
`installer.template.sh`). Run it as root on the Wazuh manager host of the test environment:

    sudo bash install-gworkspace-sync.sh            # asks for the indexer URL (default https://127.0.0.1:9200), user (admin), password

Order: (1) reachability of sts.mtls / iamcredentials / oauth2 / admin.googleapis.com and PyPI, (2) indexer login,
(3) rule-id conflict check (100800-100880 against /var/ossec/etc/rules, /var/ossec/ruleset/rules and any `<rule_dir>`;
optional `USED_RULE_IDS_FILE=/path/used_wazuh_rules_ids.txt`), (4) install: certificate + WIF config in /etc/gworkspace-sync,
python venv, sync, unit, logrotate, a dry-run of the keyless auth, Wazuh rules + localfile (validated with wazuh-analysisd -t,
rolled back on error), service start, wait for events in wazuh-alerts-*.

Options: `--yes`, `--insecure`, `--cert-dir DIR` (use your own client.crt/client.key/ca.crt), `--uninstall`, `--uninstall --purge`.

SECURITY: the built script embeds client.key. It is created mode 0700; do not share or commit it, delete it after use.
GeoIP: before the service starts, the indexer's GeoLite2-City.mmdb is replaced with DB-IP City Lite (CC BY 4.0, metadata type patched; original kept as .orig-STAMP; indexer restarted once; skipped with --skip-geoip or when the indexer is not on this host).
End of run: the script waits for events in wazuh-alerts-*, then prints the count, per-application counts, events with a source IP / country, the countries, the last sync heartbeat and the newest events. It exits non-zero (with a diagnosis) if nothing arrived.
Not included: the Ageleia dashboard section (the 8088 app / Wazuh dashboard plugin).

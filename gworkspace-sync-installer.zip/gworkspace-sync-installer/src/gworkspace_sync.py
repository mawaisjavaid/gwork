#!/usr/bin/env python3
"""Google Workspace audit sync -> JSONL for Wazuh (follows claude_sync.py: one JSON event per line, plus heartbeat lines).

Keyless auth: X.509 client cert -> Workload Identity Federation (STS) -> IAM Credentials signJwt
(sub = delegated admin) -> OAuth token via domain-wide delegation -> Admin SDK Reports API.

Every activity becomes one line:
  {"integration":"google-workspace","feed":"activity","type":"gws_activity","gws":{...},"raw_json":"<Reports API item>"}
gws.* holds what the Ageleia Google Workspace screens and the Wazuh rules (100800-100880) use: workload, page, category,
outcome, event_name, actor, ip_address, target, params and a few detection signals computed here (external_share, ...).
Settings come from the environment (/etc/gworkspace-sync/env).
"""
import calendar
import collections
import fcntl
import json
import os
import random
import re
import sys
import time
from pathlib import Path

import requests
import google.auth
import google.auth.transport.requests as gtr

BASE_DIR = Path(os.environ.get("GWORKSPACE_SYNC_DIR", "/opt/gworkspace"))
OUT_PATH = BASE_DIR / os.environ.get("GWORKSPACE_OUTPUT", "gworkspace_activities.jsonl")
STATE_PATH = BASE_DIR / "state.json"
LOCK_PATH = BASE_DIR / "sync.lock"

WIF_CONFIG = os.environ.get("GWORKSPACE_WIF_CONFIG", "/etc/gworkspace-sync/wif-credential-config.json")
SA_EMAIL = os.environ.get("GWORKSPACE_SERVICE_ACCOUNT", "")
ADMIN_EMAIL = os.environ.get("GWORKSPACE_DELEGATED_ADMIN", "")
CUSTOMER_ID = os.environ.get("GWORKSPACE_CUSTOMER_ID", "my_customer")
DOMAINS = [d.strip().lower() for d in os.environ.get("GWORKSPACE_DOMAINS", "").split(",") if d.strip()] \
    or ([ADMIN_EMAIL.split("@")[1].lower()] if "@" in ADMIN_EMAIL else [])
TRUSTED_APPS = [a.strip().lower() for a in os.environ.get("GWORKSPACE_TRUSTED_APPS", "").split(",") if a.strip()]
SCOPE = "https://www.googleapis.com/auth/admin.reports.audit.readonly"
CLIENT_ID = os.environ.get("GWORKSPACE_CLIENT_ID", "")
CLIENT_CERT = os.environ.get("GWORKSPACE_CLIENT_CERT", "/etc/gworkspace-sync/certs/client.crt")
ALL_APPS = ("login,admin,drive,token,saml,calendar,user_accounts,groups,groups_enterprise,meet,chat,mobile,rules,"
            "gmail,gcp,access_transparency,context_aware_access")
APPLICATIONS = [a.strip() for a in os.environ.get("GWORKSPACE_APPLICATIONS", ALL_APPS).split(",") if a.strip()]
INTERVAL = int(os.environ.get("GWORKSPACE_SYNC_INTERVAL", "60"))
OVERLAP_SECONDS = int(os.environ.get("GWORKSPACE_OVERLAP_SECONDS", "3600"))      # Reports API events arrive late
LOOKBACK_HOURS = int(os.environ.get("GWORKSPACE_FIRST_RUN_LOOKBACK_HOURS", "168"))
PAGE_LIMIT = max(1, min(int(os.environ.get("GWORKSPACE_PAGE_LIMIT", "1000")), 1000))
MAX_PAGES = int(os.environ.get("GWORKSPACE_MAX_PAGES", "200"))
RETRIES = int(os.environ.get("GWORKSPACE_RETRIES", "5"))
BACKOFF = float(os.environ.get("GWORKSPACE_BACKOFF", "2"))
BACKOFF_MULT = float(os.environ.get("GWORKSPACE_BACKOFF_MULT", "2"))
BACKOFF_MAX = float(os.environ.get("GWORKSPACE_BACKOFF_MAX", "120"))
DEDUPE_CACHE = int(os.environ.get("GWORKSPACE_DEDUPE_CACHE", "20000"))
UNAVAILABLE_RECHECK = int(os.environ.get("GWORKSPACE_UNAVAILABLE_RECHECK_SECONDS", "21600"))   # edition-dependent apps

# application -> Ageleia workload key (the design's categories) and page
WORKLOAD = {"login": "login", "admin": "admin", "drive": "drive", "token": "token", "saml": "saml", "calendar": "calendar",
            "user_accounts": "user_accounts", "groups": "groups", "groups_enterprise": "groups", "meet": "meet", "chat": "chat",
            "mobile": "mobile", "rules": "rules", "gmail": "gmail", "gcp": "gcp",
            "access_transparency": "access_transparency", "context_aware_access": "context_aware_access"}
PAGE = {"login": "identity", "saml": "identity", "token": "identity", "user_accounts": "identity", "admin": "security",
        "gmail": "mail", "calendar": "mail", "drive": "drive", "groups": "drive", "chat": "drive", "meet": "drive",
        "rules": "security", "mobile": "security", "gcp": "security", "access_transparency": "security",
        "context_aware_access": "security"}


def log(msg):
    print(f"{time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())} {msg}", flush=True)


class SyncError(Exception):
    pass


class AuthError(SyncError):
    pass


# ---------------------------------------------------------------- auth (keyless)
_TOKEN = {"value": None, "exp": 0}


def workspace_token(force=False):
    if not force and _TOKEN["value"] and time.time() < _TOKEN["exp"] - 300:
        return _TOKEN["value"]
    creds, _ = google.auth.load_credentials_from_file(
        WIF_CONFIG, scopes=["https://www.googleapis.com/auth/cloud-platform"])
    creds.refresh(gtr.Request())
    now = int(time.time())
    claims = {"iss": SA_EMAIL, "sub": ADMIN_EMAIL, "scope": SCOPE,
              "aud": "https://oauth2.googleapis.com/token", "iat": now, "exp": now + 3600}
    r = requests.post(
        f"https://iamcredentials.googleapis.com/v1/projects/-/serviceAccounts/{SA_EMAIL}:signJwt",
        headers={"Authorization": f"Bearer {creds.token}"}, json={"payload": json.dumps(claims)}, timeout=30)
    if r.status_code != 200:
        raise AuthError(f"signJwt failed: HTTP {r.status_code} {r.text[:300]}")
    r = requests.post("https://oauth2.googleapis.com/token", data={
        "grant_type": "urn:ietf:params:oauth:grant-type:jwt-bearer", "assertion": r.json()["signedJwt"]}, timeout=30)
    if r.status_code != 200:
        raise AuthError(f"token exchange failed: HTTP {r.status_code} {r.text[:300]}")
    _TOKEN["value"] = r.json()["access_token"]
    _TOKEN["exp"] = now + int(r.json().get("expires_in", 3600))
    return _TOKEN["value"]


def auth_info():
    info = {"method": "workload-identity-federation", "signing": "iamcredentials signJwt", "key": "none (org policy blocks service account keys)"}
    try:
        info["audience"] = json.load(open(WIF_CONFIG)).get("audience", "")
    except Exception:
        pass
    try:
        from cryptography import x509
        c = x509.load_pem_x509_certificate(open(CLIENT_CERT, "rb").read())
        cn = c.subject.get_attributes_for_oid(x509.NameOID.COMMON_NAME)
        info["cert_cn"] = cn[0].value if cn else ""
        info["cert_expires"] = c.not_valid_after_utc.strftime("%Y-%m-%dT%H:%M:%SZ") if hasattr(c, "not_valid_after_utc") else c.not_valid_after.strftime("%Y-%m-%dT%H:%M:%SZ")
    except Exception:
        pass
    return info


# ---------------------------------------------------------------- time helpers
def rfc3339(ts):
    return time.strftime("%Y-%m-%dT%H:%M:%S.000Z", time.gmtime(ts))


def parse_time(s):
    return calendar.timegm(time.strptime(s.split(".")[0].rstrip("Z"), "%Y-%m-%dT%H:%M:%S"))


# ---------------------------------------------------------------- normalisation
def param_value(p):
    if "value" in p:
        return p["value"]
    if "boolValue" in p:
        return "true" if p["boolValue"] else "false"
    if "intValue" in p:
        return str(p["intValue"])
    if "multiValue" in p:
        return [str(x) for x in p["multiValue"]]
    if "messageValue" in p:
        return json.dumps(p["messageValue"], separators=(",", ":"))
    if "multiMessageValue" in p:
        return json.dumps(p["multiMessageValue"], separators=(",", ":"))
    return ""


MAX_PARAM_CHARS = 2000
MAX_RAW_CHARS = 20000


def clip(v):
    """Wazuh maps strings as keyword (no ignore_above); a value over 32 KB would make the index reject the whole alert."""
    if isinstance(v, list):
        return [clip(x) for x in v[:50]]
    return v if not isinstance(v, str) or len(v) <= MAX_PARAM_CHARS else v[:MAX_PARAM_CHARS] + "..."


def as_list(v):
    return v if isinstance(v, list) else ([] if v in (None, "") else [v])


def is_external(email):
    e = str(email or "").strip().lower()
    if "@" not in e or not DOMAINS:
        return False
    return e.split("@", 1)[1] not in DOMAINS and not e.endswith(".calendar.google.com")


ADMIN_LIFECYCLE = {"CREATE_USER", "DELETE_USER", "SUSPEND_USER", "UNSUSPEND_USER", "RENAME_USER", "UNDELETE_USER",
                   "CHANGE_PASSWORD", "CHANGE_PASSWORD_ON_NEXT_LOGIN", "RESET_USER_RECOVERY_INFO"}
ADMIN_ROLE = {"ASSIGN_ROLE", "UNASSIGN_ROLE", "ADD_PRIVILEGE", "REMOVE_PRIVILEGE", "CREATE_ROLE", "DELETE_ROLE",
              "RENAME_ROLE", "UPDATE_ROLE"}
SECURITY_SETTING = re.compile(r"(2SV|TWO_STEP|2_STEP|SHARING|LESS_SECURE|ACCESS|PASSWORD|SSO|SAML|API|OAUTH|SECURITY|"
                              r"EXTERNAL|RECOVERY|SESSION|DELEGAT|TRUSTED)", re.I)
DRIVE_ACCESS = {"view", "download", "edit", "create", "delete", "trash", "untrash", "upload", "copy", "move", "rename",
                "preview", "print", "add_to_folder", "remove_from_folder", "sync_item_content", "source_copy"}
PUBLIC_VIS = {"people_with_link", "public_on_the_web", "public_in_the_domain"}
BROAD_SCOPE = re.compile(r"(auth/gmail|mail\.google\.com|auth/drive(?!\.(?:file|appdata|metadata\.readonly|install)\b))", re.I)


def signals_for(app, name, params):
    """Detection signals computed once here so the Wazuh rules stay simple and the domain list lives in one place."""
    s = {}
    low = {k.lower(): v for k, v in params.items()}
    vis = str(low.get("visibility", "")).lower()
    if app == "drive" and name == "change_user_access":
        tgt = low.get("target_user") or low.get("target_user_email") or ""
        if vis == "shared_externally" or is_external(tgt):
            s["external_share"] = "true"
    if app == "drive" and name in ("change_document_visibility", "change_document_access_scope"):
        if vis in PUBLIC_VIS:
            s["public_link"] = "true"
    if app == "token" and CLIENT_ID and str(low.get("client_id", "")) == CLIENT_ID:
        s["own_sync"] = "true"          # this collector's own token grants: suppressed by rule 100806, like claude_sync
    if app == "token" and name == "authorize":
        scopes = " ".join(as_list(low.get("scope")))
        appname = str(low.get("app_name", "")).lower()
        if BROAD_SCOPE.search(scopes) and appname not in TRUSTED_APPS:
            s["broad_oauth_scope"] = "true"
    if app == "user_accounts" and name == "2sv_disable":
        s["twosv_off"] = "true"
    if app == "admin" and name in ("ASSIGN_ROLE", "ADD_PRIVILEGE"):
        s["privilege_grant"] = "true"
    if app == "admin" and name == "CHANGE_APPLICATION_SETTING":
        text = " ".join(str(low.get(k, "")) for k in ("setting_name", "application_name", "new_value"))
        if SECURITY_SETTING.search(text):
            s["security_setting"] = "true"
    if app == "gmail" and name == "auto_forwarding_enabled":
        tgt = low.get("forward_to") or low.get("forward_to_address") or low.get("forward_to_domain") or ""
        if (tgt and (is_external(tgt) or ("@" not in str(tgt) and str(tgt).lower() not in DOMAINS))) or not tgt:
            s["external_forward"] = "true"
    if app == "calendar" and name in ("change_calendar_acls", "change_acls"):
        who = " ".join(str(low.get(k, "")) for k in ("user_email", "grantee_email", "grantee", "acl_scope_type"))
        if re.search(r"public|__public_principal__|default", who, re.I):
            s["public_calendar"] = "true"
    if app in ("groups", "groups_enterprise") and name in ("add_user", "add_member", "add_user_with_roles"):
        who = [low.get(k) for k in ("user_email", "member_email", "member_id", "user")]
        if any(is_external(w) for w in who):
            s["external_member"] = "true"
    if app == "mobile" and name == "DEVICE_COMPLIANCE_CHANGED_EVENT":
        if "NON_COMPLIANT" in str(low.get("new_value", "")).upper():
            s["device_noncompliant"] = "true"
    if app == "rules" and name == "rule_triggered" and str(low.get("severity", "")).upper() == "HIGH":
        s["rule_high"] = "true"
    return s


def classify(app, name, params, signals):
    """-> (category, outcome). Category and outcome names are the ones the Ageleia screens filter on."""
    low = {k.lower(): v for k, v in params.items()}
    if app == "login":
        if name == "login_failure":
            return "Authentication", "Failure"
        if name.startswith("suspicious") or name in ("gov_attack_warning",):
            return "Authentication", "Suspicious"
        if name == "login_challenge" and "fail" in str(low.get("login_challenge_status", "")).lower():
            return "Authentication", "Notice"
        if name.startswith("account_disabled") or name in ("account_warning", "login_challenge", "risky_sensitive_action_blocked"):
            return "Authentication", "Notice"
        return "Authentication", "Success"
    if app == "saml":
        return "SSO", ("Failure" if name == "login_failure" else "Success")
    if app == "token":
        if name == "activity":
            return "OAuth activity", "Success"
        return "OAuth grant", ("Notice" if signals.get("broad_oauth_scope") else "Success")
    if app == "user_accounts":
        risky = name in ("2sv_disable", "recovery_email_edit", "recovery_phone_edit", "recovery_secret_qa_edit",
                         "passkey_removed", "titanium_unenroll")
        return "Account security", ("Notice" if risky else "Success")
    if app == "admin":
        if name in ADMIN_ROLE:
            return "Privilege change", ("Notice" if signals.get("privilege_grant") else "Success")
        if name == "CHANGE_APPLICATION_SETTING" and signals.get("security_setting"):
            return "Security setting", "Notice"
        if name in ADMIN_LIFECYCLE:
            return "Account administration", "Success"
        return "Workspace configuration", "Success"
    if app == "drive":
        if name == "change_user_access":
            return ("External sharing", "Notice") if signals.get("external_share") else ("Permission change", "Success")
        if name in ("change_document_visibility", "change_document_access_scope"):
            return ("Public link", "Notice") if signals.get("public_link") else ("Permission change", "Success")
        if name in ("change_acl_editors", "change_document_access"):
            return "Permission change", "Success"
        return "File access", "Success"
    if app in ("groups", "groups_enterprise"):
        return "Group administration", ("Notice" if signals.get("external_member") else "Success")
    if app == "chat":
        return ("External collaboration", "Notice") if "external" in name else ("Chat collaboration", "Success")
    if app == "meet":
        return "Meetings", "Success"
    if app == "calendar":
        if "acl" in name:
            return ("Calendar sharing", "Notice") if signals.get("public_calendar") else ("Calendar permissions", "Success")
        return "Calendar activity", "Success"
    if app == "gmail":
        if name == "auto_forwarding_enabled":
            return "Forwarding", ("Notice" if signals.get("external_forward") else "Success")
        if name == "spam_classification":
            return "Spam", "Notice"
        if name == "quarantine_action":
            return "Quarantine", "Notice"
        if "access" in name:
            return "Message access", "Success"
        return "Message delivery", "Success"
    if app == "rules":
        return "Security rule", "Notice"
    if app == "mobile":
        return "Device", ("Notice" if signals.get("device_noncompliant") or name == "SUSPICIOUS_ACTIVITY_EVENT" else "Success")
    if app == "access_transparency":
        return "Google staff access", "Notice"
    if app == "context_aware_access":
        return "Context-aware access", "Failure"
    return "Other", "Success"


TARGET_KEYS = ("doc_title", "app_name", "application_name", "calendar_id", "event_title", "USER_EMAIL", "ROLE_NAME",
               "PRIVILEGE_NAME", "SETTING_NAME", "GROUP_EMAIL", "group_email", "DEVICE_MODEL", "device_model", "rule_name",
               "RULE_NAME", "room_name", "space_name", "meeting_code", "target_user", "user_email", "SERVICE_NAME")


def target_for(params):
    for k in TARGET_KEYS:
        v = params.get(k)
        if v:
            return str(as_list(v)[0])[:200]
    return ""


def flatten(app, item):
    """One Reports API activity -> one record per events[] entry."""
    ident = item.get("id", {})
    actor = item.get("actor", {})
    raw = json.dumps(item, separators=(",", ":"), ensure_ascii=False)
    if len(raw) > MAX_RAW_CHARS:
        raw = json.dumps({"truncated": True, "id": item.get("id"), "actor": item.get("actor"), "ipAddress": item.get("ipAddress"),
                          "events": [{"type": e.get("type"), "name": e.get("name")} for e in item.get("events", [])]},
                         separators=(",", ":"), ensure_ascii=False)
    out = []
    for idx, ev in enumerate(item.get("events") or [{}]):
        name = ev.get("name") or ""
        params = {p["name"]: clip(param_value(p)) for p in ev.get("parameters", []) if p.get("name")}
        signals = signals_for(app, name, params)
        category, outcome = classify(app, name, params, signals)
        page = PAGE.get(app, "security")
        if app == "admin" and category == "Account administration":
            page = "identity"
        gws = {
            "application": app,
            "workload": WORKLOAD.get(app, app),
            "page": page,
            "category": category,
            "outcome": outcome,
            "event_name": name,
            "event_type": ev.get("type") or "",
            "event_time": ident.get("time"),
            "unique_id": f"{ident.get('uniqueQualifier')}-{idx}",
            "customer_id": ident.get("customerId"),
            "actor": {"email": actor.get("email") or "", "profile_id": actor.get("profileId") or "",
                      "caller_type": actor.get("callerType") or ""},
            "ip_address": item.get("ipAddress") or "",
            "target": target_for(params),
            "params": params,
        }
        if signals:
            gws["signals"] = signals
        rec = {"integration": "google-workspace", "feed": "activity", "type": "gws_activity",
               "id": f"{ident.get('time')}|{ident.get('uniqueQualifier')}|{idx}", "gws": gws, "raw_json": raw}
        # Wazuh enrichment aliases, as in claude_sync: srcip gives GeoLocation (the indexer geolocates data.srcip), srcuser fills the user column
        if gws["ip_address"]:
            rec["srcip"] = gws["ip_address"]
        if gws["actor"]["email"]:
            rec["srcuser"] = gws["actor"]["email"]
        out.append(rec)
    return out


# ---------------------------------------------------------------- Reports API
class AppUnavailable(SyncError):
    pass


def request_with_retry(url, params):
    delay = BACKOFF
    for attempt in range(1, RETRIES + 1):
        r = requests.get(url, headers={"Authorization": f"Bearer {workspace_token()}"}, params=params, timeout=60)
        if r.status_code == 401 and attempt == 1:
            workspace_token(force=True)
            continue
        if r.status_code in (429, 500, 502, 503, 504) and attempt < RETRIES:
            time.sleep(min(BACKOFF_MAX, delay) * (0.5 + random.random()))
            delay *= BACKOFF_MULT
            continue
        return r
    return r


def fetch(app, start, stats):
    """Yield activities newest-first; sets stats['complete'] False when the page cap was hit."""
    url = f"https://admin.googleapis.com/admin/reports/v1/activity/users/all/applications/{app}"
    params = {"customerId": CUSTOMER_ID, "startTime": rfc3339(start), "maxResults": PAGE_LIMIT}
    pages = 0
    while True:
        r = request_with_retry(url, params)
        stats["requests"] += 1
        stats["http"] = r.status_code
        if r.status_code in (400, 403, 404):
            raise AppUnavailable(f"HTTP {r.status_code} {r.text[:200]}")
        if r.status_code == 401:
            raise AuthError(f"Reports API unauthorized: {r.text[:200]}")
        if r.status_code != 200:
            raise SyncError(f"HTTP {r.status_code} {r.text[:200]}")
        data = r.json()
        yield from data.get("items", [])
        pages += 1
        if not data.get("nextPageToken"):
            stats["complete"] = True
            return
        if pages >= MAX_PAGES:
            stats["complete"] = False
            return
        params["pageToken"] = data["nextPageToken"]


# ---------------------------------------------------------------- state
def load_state():
    try:
        return json.loads(STATE_PATH.read_text())
    except (FileNotFoundError, ValueError):
        return {}


def save_state(state):
    tmp = STATE_PATH.with_suffix(".tmp")
    with open(tmp, "w") as f:
        json.dump(state, f)
        f.flush()
        os.fsync(f.fileno())
    os.chmod(tmp, 0o640)
    os.replace(tmp, STATE_PATH)


def append_lines(lines):
    if not lines:
        return
    with open(OUT_PATH, "a") as f:
        f.write("\n".join(lines) + "\n")
        f.flush()
        os.fsync(f.fileno())


# ---------------------------------------------------------------- one sync cycle
def sync_app(app, state, dry_run):
    st = state.setdefault(app, {"checkpoint": None, "seen": [], "total": 0})
    now = time.time()
    info = {"status": "ok", "new": 0, "duplicates": 0, "requests": 0, "http": 0, "error": ""}
    if st.get("unavailable_until", 0) > now:
        info.update(status="unavailable", error=st.get("last_error", ""), http=st.get("last_http", 0))
        return info, []
    start = (st["checkpoint"] - OVERLAP_SECONDS) if st.get("checkpoint") else now - LOOKBACK_HOURS * 3600
    seen = collections.deque(st.get("seen", []), maxlen=DEDUPE_CACHE)
    seen_set = set(seen)
    newest = st.get("checkpoint") or 0
    lines = []
    stats = {"requests": 0, "http": 0, "complete": True}
    try:
        for item in fetch(app, start, stats):
            ident = item.get("id", {})
            key = f"{ident.get('time')}|{ident.get('uniqueQualifier')}"
            if key in seen_set:
                info["duplicates"] += 1
                continue
            seen.append(key)
            seen_set.add(key)
            newest = max(newest, parse_time(ident["time"]))
            lines.extend(json.dumps(r, separators=(",", ":"), ensure_ascii=False) for r in flatten(app, item))
    except AppUnavailable as e:
        st["unavailable_until"] = now + UNAVAILABLE_RECHECK
        st["last_error"], st["last_http"] = str(e)[:240], stats["http"]
        info.update(status="unavailable", error=st["last_error"], requests=stats["requests"], http=stats["http"])
        return info, []
    info.update(requests=stats["requests"], http=stats["http"], new=len(lines))
    st.pop("unavailable_until", None)
    st["last_error"] = ""
    if not dry_run:
        # events are written by the caller; the checkpoint only moves when every page was read
        if stats["complete"]:
            st["checkpoint"] = newest or st.get("checkpoint") or now
        st["seen"] = list(seen)
        st["total"] = st.get("total", 0) + len(lines)
        st["last_ok"] = now
    info["total"] = st.get("total", 0)
    info["complete"] = stats["complete"]
    if st.get("checkpoint"):
        info["checkpoint"] = rfc3339(st["checkpoint"])
    return info, lines


def run_once(dry_run=False):
    t0 = time.time()
    state = load_state()
    apps, all_lines, errors = {}, [], 0
    status = "ok"
    err_text = ""
    for app in APPLICATIONS:
        try:
            info, lines = sync_app(app, state, dry_run)
        except AuthError as e:
            status, err_text = "error", str(e)
            break
        except Exception as e:
            info, lines = {"status": "error", "new": 0, "duplicates": 0, "requests": 0, "http": 0, "error": str(e)[:240]}, []
            errors += 1
        apps[app] = info
        all_lines.extend(lines)
    if dry_run:
        if status == "error":   # authentication failed: a dry run must say so (the installer relies on the exit code)
            raise RuntimeError(err_text or "authentication failed")
        if apps and all(i.get("status") == "error" for i in apps.values()):
            raise RuntimeError("every application failed: " + "; ".join(sorted({str(i.get('error', ''))[:100] for i in apps.values()})))
        log(f"[dry-run] {sum(len(l) for l in [all_lines])} new event line(s); apps: " +
            ", ".join(f"{a}={i['status']}:{i['new']}" for a, i in apps.items()))
        for line in all_lines[:3]:
            print(line[:600])
        return len(all_lines)
    new = len(all_lines)
    hb = {"integration": "google-workspace", "feed": "activity", "type": "athena_gws_sync_heartbeat",
          "id": "heartbeat_" + time.strftime("%Y%m%dT%H%M%S", time.gmtime()),
          "created_at": time.strftime("%Y-%m-%dT%H:%M:%S.000000Z", time.gmtime()),
          "sync": {"status": status if status == "error" else ("warn" if errors else "ok"), "error": err_text,
                   "interval_seconds": INTERVAL, "new_events": new, "duration_ms": int((time.time() - t0) * 1000),
                   "requests": sum(i.get("requests", 0) for i in apps.values()),
                   "duplicates": sum(i.get("duplicates", 0) for i in apps.values()),
                   "overlap_seconds": OVERLAP_SECONDS, "lookback_hours": LOOKBACK_HOURS, "page_limit": PAGE_LIMIT,
                   "max_pages": MAX_PAGES, "retries": RETRIES, "customer_id": CUSTOMER_ID,
                   "domain": DOMAINS[0] if DOMAINS else "", "domains": ",".join(DOMAINS),
                   "service_account": SA_EMAIL, "client_id": CLIENT_ID, "delegated_admin": ADMIN_EMAIL, "scope": SCOPE,
                   "auth": "workload-identity-federation + signJwt (no key)", "auth_info": auth_info(), "failed_apps": errors,
                   "backoff": BACKOFF, "backoff_mult": BACKOFF_MULT, "backoff_max": BACKOFF_MAX,
                   "apps": apps}}
    append_lines(all_lines + [json.dumps(hb, separators=(",", ":"))])
    if status != "error":
        save_state(state)
    log(f"{status}: {new} new event(s), {hb['sync']['requests']} request(s), "
        f"{sum(1 for i in apps.values() if i['status'] == 'unavailable')} app(s) unavailable, {errors} failed"
        + (f" | {err_text}" if err_text else ""))
    return new


def main():
    for name, val in (("GWORKSPACE_SERVICE_ACCOUNT", SA_EMAIL), ("GWORKSPACE_DELEGATED_ADMIN", ADMIN_EMAIL)):
        if not val:
            sys.exit(f"{name} is not set")
    once = "--once" in sys.argv
    dry = "--dry-run" in sys.argv
    lock = open(LOCK_PATH, "w")
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        sys.exit("another gworkspace_sync is already running")
    log(f"start: apps={len(APPLICATIONS)} admin={ADMIN_EMAIL} interval={INTERVAL}s domains={','.join(DOMAINS)}")
    while True:
        try:
            run_once(dry_run=dry)
        except Exception as e:   # keep polling; the error is in the journal and in the next heartbeat
            log(f"ERROR: {e}")
            if once or dry:
                sys.exit(1)
        if once or dry:
            break
        time.sleep(INTERVAL)


if __name__ == "__main__":
    main()

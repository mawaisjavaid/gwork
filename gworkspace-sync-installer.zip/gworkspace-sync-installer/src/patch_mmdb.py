#!/usr/bin/env python3
"""usage: patch_mmdb.py IN.mmdb OUT.mmdb
DB-IP "City Lite" is a MaxMind-format database, but its metadata says database_type=DBIP-City-Lite, which the indexer's
geoip processor rejects ("Unsupported database type"). Rewrite that one metadata string to GeoLite2-City (the metadata map
sits after the data section, so the 1-byte length change shifts nothing the search tree points to)."""
import sys

d = open(sys.argv[1], "rb").read()
m = d.rfind(b"\xab\xcd\xefMaxMind.com")
if m < 0:
    sys.exit("not a MaxMind DB file (metadata marker not found)")
meta = d[m:]
old, new = b"\x4eDBIP-City-Lite", b"\x4dGeoLite2-City"
if meta.count(old) != 1:
    sys.exit("unexpected database_type in the metadata (expected exactly one DBIP-City-Lite)")
open(sys.argv[2], "wb").write(d[:m] + meta.replace(old, new))
print("patched")

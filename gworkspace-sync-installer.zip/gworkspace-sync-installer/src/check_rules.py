#!/usr/bin/env python3
"""Rule-ID conflict check for the Google Workspace rules.

usage: check_rules.py NEW_RULES_FILE OWN_BASENAME RULE_DIR [RULE_DIR ...] [--used-ids FILE]
Reads every *.xml rule file in the given directories (what Wazuh loads), collects <rule id="..."> and compares it with the
IDs in NEW_RULES_FILE. A file called OWN_BASENAME is skipped (re-running the installer must not conflict with itself).
Exit 0: no conflict. Exit 1: conflicts (listed). Exit 2: could not read the new file.
"""
import glob, os, re, sys
import xml.etree.ElementTree as ET


def rule_ids(path):
    """{id: description} for one rule file. Wazuh rule files have several top-level <group> elements, so wrap them."""
    try:
        txt = open(path, encoding="utf-8", errors="replace").read()
    except OSError:
        return {}
    body = re.sub(r"^\s*<\?xml[^>]*\?>", "", txt)
    out = {}
    try:
        root = ET.fromstring("<root>" + body + "</root>")
        for r in root.iter("rule"):
            rid = r.get("id")
            if rid and rid.isdigit():
                d = r.find("description")
                out[int(rid)] = " ".join((d.text or "").split())[:90] if d is not None else ""
    except ET.ParseError:   # not well-formed (a half-edited custom file): fall back to a plain scan so nothing is missed
        for m in re.finditer(r'<rule\s[^>]*\bid\s*=\s*"(\d+)"', re.sub(r"<!--.*?-->", "", body, flags=re.S)):
            out[int(m.group(1))] = "(file is not well-formed XML; found by text scan)"
    return out


def main():
    a = sys.argv[1:]
    used_file = None
    if "--used-ids" in a:
        i = a.index("--used-ids"); used_file = a[i + 1]; del a[i:i + 2]
    new_file, own, dirs = a[0], a[1], a[2:]
    mine = rule_ids(new_file)
    if not mine:
        print("cannot read any rule ids from " + new_file); return 2
    print("  new rules: %d ids, %d-%d" % (len(mine), min(mine), max(mine)))
    seen, conflicts, scanned = {}, [], 0
    for d in dirs:
        for f in sorted(glob.glob(os.path.join(d, "*.xml"))):
            if os.path.basename(f) == own:
                continue
            scanned += 1
            for rid, desc in rule_ids(f).items():
                seen.setdefault(rid, (f, desc))
    print("  compared with %d existing rule file(s) in: %s" % (scanned, ", ".join(dirs)))
    for rid in sorted(mine):
        if rid in seen:
            conflicts.append("rule %d is already defined in %s  (%s)" % (rid, seen[rid][0], seen[rid][1]))
    if used_file:
        try:
            used = {int(x) for x in re.findall(r"\b\d{5,7}\b", open(used_file).read())}
            hit = sorted(set(mine) & used)
            print("  compared with the used-ids list %s (%d ids)" % (used_file, len(used)))
            for rid in hit:
                conflicts.append("rule %d is listed as used in %s" % (rid, used_file))
        except OSError as e:
            print("  warning: could not read " + used_file + ": " + str(e))
    if conflicts:
        print("CONFLICT:")
        for c in conflicts:
            print("   - " + c)
        return 1
    print("  no conflicts")
    return 0


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env bash
# =====================================================================================================================
# Google Workspace -> Wazuh sync: one-shot installer (everything up to the indexer; the Ageleia dashboard is NOT included)
#
# Run it on the host that runs the Wazuh manager. In this order it:
#   1. checks that this server can reach Google (STS, IAM Credentials, OAuth, Reports API) and PyPI
#   2. asks for the indexer URL (default https://127.0.0.1:9200), user (default admin) and password, and tests them
#   3. checks that the Google Workspace rule ids (100800-100880) do not conflict with any rule already on this manager
#   4. only if all of that passed:
#        - installs the sync service (/opt/gworkspace, python venv, systemd unit gworkspace-sync, logrotate)
#        - installs the keyless-auth certificate and the Workload Identity Federation config in /opt/gworkspace/certs
#        - runs the sync once in dry-run mode: certificate -> Google token -> signJwt -> delegated Reports API token
#        - installs the Wazuh rules and the <localfile> block, validates them with wazuh-analysisd -t (rolls back on error)
#        - updates the indexer's GeoIP database (DB-IP City Lite, CC BY 4.0) so source IPs get the right country
#        - starts the service, waits until the events show up in wazuh-alerts-*, and prints what arrived (apps, countries, newest events)
#
# Authentication is keyless: no service account key exists. The client certificate (X.509) is exchanged for a Google
# token through Workload Identity Federation, Google signs the delegated-admin JWT (IAM Credentials signJwt), and the
# JWT is exchanged for a read-only Reports API token (domain-wide delegation, admin.reports.audit.readonly).
#
# NOTE: this script contains the client certificate AND its private key (client.key). Treat the file like a credential:
# keep it mode 0700, do not share or commit it, and delete it after the install.
#
# Usage:   sudo bash install-gworkspace-sync.sh [--yes] [--insecure] [--skip-geoip] [--cert-dir DIR] [--uninstall] [--purge]
#   --yes         do not ask before restarting wazuh-manager
#   --insecure    do not verify the indexer's TLS certificate (also INDEXER_INSECURE=1). Without it the script verifies the
#                 certificate and, if its host name does not match the URL (typical for https://127.0.0.1:9200), falls back
#                 to skipping verification for the indexer only, with a warning.
#   --skip-geoip  do not update the indexer's GeoIP database (step "GeoIP")
#   --cert-dir D  use client.crt, client.key and ca.crt from directory D instead of the ones embedded in this script
#   --uninstall   stop and remove the service, rules, localfile block and logrotate policy (keeps data and certificates)
#   --purge       with --uninstall: also delete /opt/gworkspace (certificates included) and /etc/gworkspace-sync
# Non-interactive: export INDEXER_PASSWORD (optionally INDEXER_URL, INDEXER_USER, INDEXER_CA, USED_RULE_IDS_FILE,
#   GWORKSPACE_SERVICE_ACCOUNT, GWORKSPACE_DELEGATED_ADMIN, GWORKSPACE_CUSTOMER_ID, GWORKSPACE_DOMAINS, GWORKSPACE_CLIENT_ID).
# =====================================================================================================================
set -euo pipefail

YES=0; UNINSTALL=0; PURGE=0; INSECURE=${INDEXER_INSECURE:-0}; CERT_SRC=""; SKIP_GEOIP=${SKIP_GEOIP:-0}
while [ $# -gt 0 ]; do
  case "$1" in
    --yes|-y) YES=1 ;; --insecure|-k) INSECURE=1 ;; --skip-geoip) SKIP_GEOIP=1 ;; --uninstall) UNINSTALL=1 ;; --purge) PURGE=1 ;;
    --cert-dir) shift; CERT_SRC=${1:-}; [ -n "$CERT_SRC" ] || { echo "--cert-dir needs a directory" >&2; exit 2; } ;;
    -h|--help) sed -n 2,40p "$0"; exit 0 ;;
    *) echo "unknown option: $1" >&2; exit 2 ;;
  esac
  shift
done

SYNC_DIR=/opt/gworkspace
ENV_DIR=/etc/gworkspace-sync
CERT_DIR=$SYNC_DIR/certs        # the certificate, its key and the WIF config live under /opt/gworkspace
VENV=$SYNC_DIR/venv
UNIT=/etc/systemd/system/gworkspace-sync.service
RULES_DIR=/var/ossec/etc/rules
OSSEC_CONF=/var/ossec/etc/ossec.conf
RULE_FILE=gworkspace_rules.xml
LOCALFILE=gworkspace_activities.jsonl
STAMP=$(date +%Y%m%d-%H%M%S)
GOOGLE_HOSTS="sts.mtls.googleapis.com iamcredentials.googleapis.com oauth2.googleapis.com admin.googleapis.com"
GEOIP_DIR=/usr/share/wazuh-indexer/modules/ingest-geoip
GEOIP_DB=$GEOIP_DIR/GeoLite2-City.mmdb

if [ -t 1 ]; then B=$'\e[1m'; G=$'\e[32m'; Y=$'\e[33m'; R=$'\e[31m'; N=$'\e[0m'; else B=; G=; Y=; R=; N=; fi
step() { echo; echo "${B}==> $*${N}"; }
ok()   { echo "  ${G}ok${N}  $*"; }
warn() { echo "  ${Y}warn${N} $*"; }
die()  { echo "  ${R}error${N} $*" >&2; exit 1; }

WORK=$(mktemp -d); chmod 700 "$WORK"
trap 'rm -rf "$WORK"' EXIT

[ "$(id -u)" -eq 0 ] || die "run as root (sudo bash $0)"
command -v systemctl >/dev/null || die "systemd is required"
command -v curl >/dev/null || die "curl is required"
command -v python3 >/dev/null || die "python3 is required"
python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)' || die "python3 >= 3.8 is required"
[ -x /var/ossec/bin/wazuh-control ] || die "Wazuh manager not found in /var/ossec (run this on the Wazuh manager host)"

# ------------------------------------------------------------------------------------------------ uninstall
if [ "$UNINSTALL" -eq 1 ]; then
  step "Uninstalling the Google Workspace sync"
  systemctl disable --now gworkspace-sync 2>/dev/null || true
  rm -f "$UNIT"; systemctl daemon-reload
  rm -f "$RULES_DIR/$RULE_FILE" /etc/logrotate.d/gworkspace-sync
  python3 - "$OSSEC_CONF" "$STAMP" <<'PY'
import re, shutil, sys
p, stamp = sys.argv[1], sys.argv[2]
s = open(p).read()
n = re.sub(r"\n[ \t]*<localfile>\s*<log_format>json</log_format>\s*<location>/opt/gworkspace/gworkspace_activities\.jsonl</location>\s*</localfile>[ \t]*", "", s)
if n != s:
    shutil.copy(p, p + ".bak-gworkspace-" + stamp); open(p, "w").write(n)
PY
  if [ "$PURGE" -eq 1 ]; then rm -rf "$SYNC_DIR" "$ENV_DIR"; ok "removed $SYNC_DIR and $ENV_DIR (certificates included)"
  else warn "kept $SYNC_DIR and $ENV_DIR (use --purge to delete, certificates included)"; fi
  ok "removed. Restart wazuh-manager to unload the rules: systemctl restart wazuh-manager"
  exit 0
fi

# ------------------------------------------------------------------------------------------------ 1. network
step "1/4  Checking that this server can reach Google and PyPI (HTTPS, port 443)"
net_fail=0
probe() {  # probe host  -> any HTTP answer (even 404) proves DNS, TCP, TLS and the egress path work
  local host=$1 code rc why
  if [ -z "${HTTPS_PROXY:-}${https_proxy:-}" ] && command -v getent >/dev/null && ! getent hosts "$host" >/dev/null 2>&1; then
    echo "  ${R}fail${N} $host: DNS does not resolve from this server (check /etc/resolv.conf, VPC DNS settings or a private DNS zone)"; net_fail=1; return
  fi
  code=$(curl -sS -o /dev/null -w '%{http_code}' --connect-timeout 10 -m 25 "https://$host/" 2>"$WORK/net.err") && rc=0 || rc=$?
  if [ "$rc" -ne 0 ]; then
    case "$rc" in
      6)  why="DNS: the name does not resolve." ;;
      7)  why="the connection was refused or reset on port 443." ;;
      28) why="timed out: typical of a firewall dropping outbound traffic (Security Group outbound TCP 443, Network ACL, route/NAT, proxy)." ;;
      35|51|58|60|77) why="TLS handshake/certificate failed: a TLS-inspecting proxy probably re-signs the traffic; install its CA on this server." ;;
      5|56) why="the proxy refused or dropped the connection (check HTTPS_PROXY / NO_PROXY)." ;;
      *)  why="curl exit code $rc." ;;
    esac
    echo "  ${R}fail${N} $host: $why"; net_fail=1
  else
    ok "$host (HTTP $code)"
  fi
}
for h in $GOOGLE_HOSTS; do probe "$h"; done
if [ "$SKIP_GEOIP" -ne 1 ] && [ -d "$GEOIP_DIR" ]; then probe download.db-ip.com; fi
if [ -x "$VENV/bin/python" ] && "$VENV/bin/python" -c 'import requests, google.auth, cryptography, OpenSSL' 2>/dev/null; then
  ok "python packages already installed in $VENV: PyPI is not needed"
else
  for h in pypi.org files.pythonhosted.org; do probe "$h"; done
fi
[ "$net_fail" -eq 0 ] || die "this server cannot reach everything the sync needs (see above). The sync only talks to those hosts over HTTPS 443.
        Ask the network/cloud admin to allow outbound access, then run this script again.
        Quick test:  curl -v https://sts.mtls.googleapis.com/   (any HTTP answer, even 404, means the path is open)"

# ------------------------------------------------------------------------------------------------ 2. indexer
step "2/4  Wazuh indexer"
if [ -t 0 ]; then TTY=/dev/stdin; elif { : </dev/tty; } 2>/dev/null; then TTY=/dev/tty; else TTY=""; fi
ask_secret() {  # ask_secret VAR "prompt"
  local var=$1 prompt=$2 v=""
  if [ -n "${!var:-}" ]; then return; fi
  [ -n "$TTY" ] || die "$var is not set and there is no terminal to ask on (export $var=... and run again)"
  while [ -z "$v" ]; do read -rsp "$prompt: " v < "$TTY"; echo >&2; done
  printf -v "$var" '%s' "$v"
}
ask() {  # ask VAR "prompt" default
  local var=$1 prompt=$2 def=$3 v=""
  if [ -n "${!var:-}" ]; then return; fi
  if [ -n "$TTY" ]; then read -rp "$prompt [$def]: " v < "$TTY"; fi
  printf -v "$var" '%s' "${v:-$def}"
}
INDEXER_PASSWORD=${INDEXER_PASSWORD:-}; INDEXER_URL=${INDEXER_URL:-}; INDEXER_USER=${INDEXER_USER:-}
ask INDEXER_URL "Wazuh indexer URL" "https://127.0.0.1:9200"
ask INDEXER_USER "Wazuh indexer user" "admin"
ask_secret INDEXER_PASSWORD "Wazuh indexer password for '$INDEXER_USER'"
INDEXER_URL=${INDEXER_URL%/}
case "$INDEXER_URL" in http://*|https://*) ;; *) INDEXER_URL="https://$INDEXER_URL" ;; esac
INDEXER_CA=${INDEXER_CA:-/etc/wazuh-indexer/certs/root-ca.pem}
if [ "$INSECURE" -eq 1 ]; then CA_OPT=(-k); elif [ -r "$INDEXER_CA" ]; then CA_OPT=(--cacert "$INDEXER_CA"); else CA_OPT=(-k); fi

# curl with the password kept off the command line (it would show in ps)
cfg_escape() { local s=$1; s=${s//\\/\\\\}; s=${s//\"/\\\"}; printf '%s' "$s"; }
ix() { curl -sS "${CA_OPT[@]}" -K <(printf 'user = "%s"\n' "$(cfg_escape "$INDEXER_USER:$INDEXER_PASSWORD")") "$@"; }

code=$(ix -o /dev/null -w '%{http_code}' -m 20 "$INDEXER_URL/" 2>"$WORK/ix.err") && rc=0 || rc=$?
if [ "$rc" -ne 0 ] && [ "${CA_OPT[0]}" != -k ]; then
  case "$rc" in
    51|58|60|77)   # certificate does not match the host name / unknown CA: expected for https://127.0.0.1 with a node-name certificate
      warn "the indexer's TLS certificate could not be verified ($(tr -d '\n' <"$WORK/ix.err" | cut -c1-110))"
      warn "continuing WITHOUT certificate verification for the indexer only (credentials go to $INDEXER_URL; use --insecure to skip this probe)"
      CA_OPT=(-k)
      code=$(ix -o /dev/null -w '%{http_code}' -m 20 "$INDEXER_URL/" 2>"$WORK/ix.err") && rc=0 || rc=$? ;;
  esac
fi
[ "$rc" -eq 0 ] || code=000
case "$code" in
  200) ok "indexer reachable at $INDEXER_URL, credentials accepted" ;;
  401) die "the indexer rejected the user/password" ;;
  *) die "the indexer at $INDEXER_URL did not answer (HTTP $code, curl exit $rc): $(tr -d '\n' <"$WORK/ix.err" 2>/dev/null | cut -c1-200)" ;;
esac
ix -m 20 "$INDEXER_URL/_cat/indices/wazuh-alerts-*?h=index" | head -1 | grep -q wazuh-alerts && ok "wazuh-alerts-* indices exist" \
  || warn "no wazuh-alerts-* index yet (it is created when the first alert arrives)"

# ------------------------------------------------------------------------------------------------ 3. rule conflicts
step "3/4  Checking the rule ids against the rules already on this manager"
cat > "$WORK/gworkspace_rules.xml" <<'__EOF_rules__'
<!--
  Google Workspace audit events (Ageleia Google Workspace section).
  Source: /opt/gworkspace/gworkspace_activities.jsonl, one JSON event per line, written by gworkspace_sync.py.
  Every line carries "integration":"google-workspace"; the Wazuh JSON decoder puts the Workspace fields under data.gws.*.
  Rule IDs 100800-100899 (the Ageleia design's band; free in the used-rule-ids list). Claude owns 102700-102839.
    100800-100806  activity, heartbeat, sync error, building blocks for the frequency rules, own-sync suppression
    100810-100880  detections: the design's R1-R14, with the design's IDs and levels
-->
<group name="gworkspace,google_workspace,">

  <!-- one alert per Workspace audit event; severity is assigned by the detections below -->
  <rule id="100800" level="3">
    <decoded_as>json</decoded_as>
    <field name="integration">^google-workspace$</field>
    <field name="type">^gws_activity$</field>
    <description>Google Workspace $(gws.application): $(gws.event_name) by $(gws.actor.email)</description>
    <group>gws_activity,</group>
  </rule>

  <!-- sync service heartbeat: one line per cycle with per-application status -->
  <rule id="100801" level="3">
    <decoded_as>json</decoded_as>
    <field name="integration">^google-workspace$</field>
    <field name="type">^athena_gws_sync_heartbeat$</field>
    <description>Google Workspace sync heartbeat: status=$(sync.status), new events=$(sync.new_events), requests=$(sync.requests).</description>
    <group>gws_heartbeat,</group>
  </rule>

  <rule id="100802" level="8">
    <if_sid>100801</if_sid>
    <field name="sync.status">^error$</field>
    <description>Google Workspace sync ERROR: $(sync.error)</description>
    <group>gws_heartbeat,gws_sync_error,</group>
  </rule>

  <rule id="100803" level="5">
    <if_sid>100801</if_sid>
    <field name="sync.status">^warn$</field>
    <description>Google Workspace sync WARNING: $(sync.failed_apps) application(s) failed this cycle.</description>
    <group>gws_heartbeat,gws_sync_error,</group>
  </rule>

  <!-- building blocks for the frequency detections (not severities of their own) -->
  <rule id="100804" level="3">
    <if_sid>100800</if_sid>
    <field name="gws.application">^login$</field>
    <field name="gws.event_name">^login_failure$</field>
    <description>Google Workspace login failure for $(gws.actor.email) from $(gws.ip_address)</description>
    <group>gws_activity,</group>
  </rule>

  <rule id="100805" level="3">
    <if_sid>100800</if_sid>
    <field name="gws.application">^drive$</field>
    <field name="gws.event_name">^download$</field>
    <description>Google Workspace Drive download by $(gws.actor.email)</description>
    <group>gws_activity,</group>
  </rule>

  <!-- the sync service's own token grants (domain-wide delegation) are audited as OAuth events: suppress them, like claude_sync's polls -->
  <rule id="100806" level="0">
    <if_sid>100800</if_sid>
    <field name="gws.signals.own_sync">^true$</field>
    <description>Google Workspace sync's own token grant (suppressed)</description>
    <group>gws_activity,gws_own_sync,</group>
  </rule>

  <!-- identity -->
  <rule id="100810" level="10" frequency="5" timeframe="600">
    <if_matched_sid>100804</if_matched_sid>
    <same_field>gws.ip_address</same_field>
    <field name="gws.ip_address">\S+</field>
    <description>Google Workspace: repeated failed sign-ins from one IP ($(gws.ip_address))</description>
    <mitre><id>T1110</id></mitre>
    <group>gws_detection,authentication_failures,</group>
  </rule>

  <rule id="100811" level="12">
    <if_sid>100800</if_sid>
    <field name="gws.event_name">^suspicious_login</field>
    <description>Google Workspace: Google flagged a suspicious sign-in for $(gws.actor.email) from $(gws.ip_address)</description>
    <mitre><id>T1078</id></mitre>
    <group>gws_detection,</group>
  </rule>

  <rule id="100812" level="9">
    <if_sid>100800</if_sid>
    <field name="gws.signals.broad_oauth_scope">^true$</field>
    <description>Google Workspace: OAuth grant with broad mail or Drive scopes to $(gws.target)</description>
    <mitre><id>T1528</id></mitre>
    <group>gws_detection,</group>
  </rule>

  <rule id="100813" level="8">
    <if_sid>100800</if_sid>
    <field name="gws.signals.twosv_off">^true$</field>
    <description>Google Workspace: 2-step verification turned off for $(gws.actor.email)</description>
    <mitre><id>T1556</id></mitre>
    <group>gws_detection,</group>
  </rule>

  <!-- drive and collaboration -->
  <rule id="100820" level="9">
    <if_sid>100800</if_sid>
    <field name="gws.signals.external_share">^true$</field>
    <description>Google Workspace: document shared outside the domain by $(gws.actor.email): $(gws.target)</description>
    <mitre><id>T1537</id></mitre>
    <group>gws_detection,</group>
  </rule>

  <rule id="100821" level="11" frequency="20" timeframe="900">
    <if_matched_sid>100805</if_matched_sid>
    <same_field>gws.actor.email</same_field>
    <description>Google Workspace: mass download by $(gws.actor.email) (20 or more in 15 minutes)</description>
    <mitre><id>T1530</id></mitre>
    <group>gws_detection,</group>
  </rule>

  <rule id="100822" level="8">
    <if_sid>100800</if_sid>
    <field name="gws.signals.public_link">^true$</field>
    <description>Google Workspace: public link enabled on a document by $(gws.actor.email): $(gws.target)</description>
    <mitre><id>T1530</id></mitre>
    <group>gws_detection,</group>
  </rule>

  <rule id="100860" level="7">
    <if_sid>100800</if_sid>
    <field name="gws.signals.external_member">^true$</field>
    <description>Google Workspace: external member added to a group by $(gws.actor.email): $(gws.target)</description>
    <mitre><id>T1098</id></mitre>
    <group>gws_detection,</group>
  </rule>

  <!-- gmail and calendar -->
  <rule id="100840" level="8">
    <if_sid>100800</if_sid>
    <field name="gws.signals.public_calendar">^true$</field>
    <description>Google Workspace: calendar shared publicly by $(gws.actor.email): $(gws.target)</description>
    <group>gws_detection,</group>
  </rule>

  <rule id="100850" level="9">
    <if_sid>100800</if_sid>
    <field name="gws.signals.external_forward">^true$</field>
    <description>Google Workspace: auto-forwarding enabled to an external address by $(gws.actor.email)</description>
    <mitre><id>T1114</id></mitre>
    <group>gws_detection,</group>
  </rule>

  <!-- security and compliance -->
  <rule id="100830" level="13">
    <if_sid>100800</if_sid>
    <field name="gws.signals.privilege_grant">^true$</field>
    <description>Google Workspace: admin privilege granted by $(gws.actor.email): $(gws.target)</description>
    <mitre><id>T1098</id></mitre>
    <group>gws_detection,</group>
  </rule>

  <rule id="100831" level="10">
    <if_sid>100800</if_sid>
    <field name="gws.signals.security_setting">^true$</field>
    <description>Google Workspace: security-relevant setting changed by $(gws.actor.email): $(gws.target)</description>
    <mitre><id>T1562</id></mitre>
    <group>gws_detection,</group>
  </rule>

  <rule id="100870" level="9">
    <if_sid>100800</if_sid>
    <field name="gws.signals.rule_high">^true$</field>
    <description>Google Workspace: security rule matched (HIGH): $(gws.target)</description>
    <group>gws_detection,</group>
  </rule>

  <rule id="100880" level="8">
    <if_sid>100800</if_sid>
    <field name="gws.signals.device_noncompliant">^true$</field>
    <description>Google Workspace: device became non-compliant: $(gws.target)</description>
    <group>gws_detection,</group>
  </rule>

</group>
__EOF_rules__
cat > "$WORK/check_rules.py" <<'__EOF_check_rules__'
#!/usr/bin/env python3
"""Rule-ID conflict check for the Google Workspace rules.

usage: check_rules.py NEW_RULES_FILE OWN_BASENAME RULE_DIR [RULE_DIR ...] [--used-ids FILE]
Reads every *.xml rule file in the given directories (what Wazuh loads), collects <rule id="..."> and compares it with the
IDs in NEW_RULES_FILE. A file called OWN_BASENAME is skipped (re-running the installer must not conflict with itself).
Exit 0: no conflict. Exit 1: conflicts (listed). Exit 2: could not read the new file.
"""
import glob, os, re, sys
import xml.etree.ElementTree as ET


def rule_ids(path):
    """{id: description} for one rule file. Wazuh rule files have several top-level <group> elements, so wrap them."""
    try:
        txt = open(path, encoding="utf-8", errors="replace").read()
    except OSError:
        return {}
    body = re.sub(r"^\s*<\?xml[^>]*\?>", "", txt)
    out = {}
    try:
        root = ET.fromstring("<root>" + body + "</root>")
        for r in root.iter("rule"):
            rid = r.get("id")
            if rid and rid.isdigit():
                d = r.find("description")
                out[int(rid)] = " ".join((d.text or "").split())[:90] if d is not None else ""
    except ET.ParseError:   # not well-formed (a half-edited custom file): fall back to a plain scan so nothing is missed
        for m in re.finditer(r'<rule\s[^>]*\bid\s*=\s*"(\d+)"', re.sub(r"<!--.*?-->", "", body, flags=re.S)):
            out[int(m.group(1))] = "(file is not well-formed XML; found by text scan)"
    return out


def main():
    a = sys.argv[1:]
    used_file = None
    if "--used-ids" in a:
        i = a.index("--used-ids"); used_file = a[i + 1]; del a[i:i + 2]
    new_file, own, dirs = a[0], a[1], a[2:]
    mine = rule_ids(new_file)
    if not mine:
        print("cannot read any rule ids from " + new_file); return 2
    print("  new rules: %d ids, %d-%d" % (len(mine), min(mine), max(mine)))
    seen, conflicts, scanned = {}, [], 0
    for d in dirs:
        for f in sorted(glob.glob(os.path.join(d, "*.xml"))):
            if os.path.basename(f) == own:
                continue
            scanned += 1
            for rid, desc in rule_ids(f).items():
                seen.setdefault(rid, (f, desc))
    print("  compared with %d existing rule file(s) in: %s" % (scanned, ", ".join(dirs)))
    for rid in sorted(mine):
        if rid in seen:
            conflicts.append("rule %d is already defined in %s  (%s)" % (rid, seen[rid][0], seen[rid][1]))
    if used_file:
        try:
            used = {int(x) for x in re.findall(r"\b\d{5,7}\b", open(used_file).read())}
            hit = sorted(set(mine) & used)
            print("  compared with the used-ids list %s (%d ids)" % (used_file, len(used)))
            for rid in hit:
                conflicts.append("rule %d is listed as used in %s" % (rid, used_file))
        except OSError as e:
            print("  warning: could not read " + used_file + ": " + str(e))
    if conflicts:
        print("CONFLICT:")
        for c in conflicts:
            print("   - " + c)
        return 1
    print("  no conflicts")
    return 0


if __name__ == "__main__":
    sys.exit(main())
__EOF_check_rules__
RULE_SCAN_DIRS=("$RULES_DIR" /var/ossec/ruleset/rules)
# extra rule directories declared in ossec.conf (<rule_dir>), relative to /var/ossec
while IFS= read -r d; do
  d=${d//[[:space:]]/}; [ -n "$d" ] || continue
  case "$d" in /*) ;; *) d="/var/ossec/$d" ;; esac
  [ -d "$d" ] && RULE_SCAN_DIRS+=("$d")
done < <(grep -o '<rule_dir[^>]*>[^<]*</rule_dir>' "$OSSEC_CONF" 2>/dev/null | sed 's/<[^>]*>//g' || true)
mapfile -t RULE_SCAN_DIRS < <(printf '%s\n' "${RULE_SCAN_DIRS[@]}" | awk '!seen[$0]++')
USED_OPT=(); if [ -n "${USED_RULE_IDS_FILE:-}" ] && [ -r "$USED_RULE_IDS_FILE" ]; then USED_OPT=(--used-ids "$USED_RULE_IDS_FILE"); fi
if python3 -I "$WORK/check_rules.py" "$WORK/gworkspace_rules.xml" "$RULE_FILE" "${RULE_SCAN_DIRS[@]}" "${USED_OPT[@]}"; then
  ok "the Google Workspace rules do not conflict with existing rules"
else
  die "rule id conflict: nothing was installed. Resolve it (renumber the Workspace rules, or retire the other rule) and run this script again."
fi

# ------------------------------------------------------------------------------------------------ 4. install
step "4/4  Installing the sync service"
GRP=root; getent group wazuh >/dev/null && GRP=wazuh
write_file() {  # write_file path mode owner:group  (content on stdin); keeps a .bak-STAMP copy of a different existing file
  local path=$1 mode=$2 own=$3 tmp; tmp=$(mktemp "$WORK/wf.XXXXXX")
  cat > "$tmp"
  if [ -e "$path" ] && ! cmp -s "$tmp" "$path"; then cp -p "$path" "$path.bak-$STAMP"; fi
  install -m "$mode" -o "${own%%:*}" -g "${own##*:}" "$tmp" "$path"; rm -f "$tmp"
}
install -d -m 2750 -o root -g "$GRP" "$SYNC_DIR"
install -d -m 0750 -o root -g root "$ENV_DIR" "$CERT_DIR"   # certs dir: root only (the key must not be group-readable)

# --- certificate (keyless authentication)
if [ -n "$CERT_SRC" ]; then
  for f in client.crt client.key ca.crt; do [ -r "$CERT_SRC/$f" ] || die "$CERT_SRC/$f not found (--cert-dir needs client.crt, client.key and ca.crt)"; done
  install -m 0644 -o root -g root "$CERT_SRC/client.crt" "$CERT_DIR/client.crt"
  install -m 0600 -o root -g root "$CERT_SRC/client.key" "$CERT_DIR/client.key"
  install -m 0644 -o root -g root "$CERT_SRC/ca.crt" "$CERT_DIR/ca.crt"
  CERT_FROM="$CERT_SRC"
else
  write_file "$CERT_DIR/client.crt" 0644 root:root <<'__EOF_client_crt__'
-----BEGIN CERTIFICATE-----
MIIDgTCCAWmgAwIBAgIUWihSJyvdxBW2Qv+0jZYO9H2cNgQwDQYJKoZIhvcNAQEL
BQAwJTEjMCEGA1UEAwwaQXRoZW5hLUdvb2dsZS1Xb3Jrc3BhY2UtQ0EwHhcNMjYx
MTEwMDczNjM5WhcNMjcxMTEwMDczNjM5WjAqMSgwJgYDVQQDDB9nb29nbGUtd29y
a3NwYWNlLXNpZW0tY29sbGVjdG9yMFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE
uyxIeZRPNjP2Pv6va7K6EjsoqsrbRJ+APtztWYLcG7soNx+MrpTMuM8Za7pI0HKN
H15Vtfc2JnsQQaV6PVgEdaNvMG0wCQYDVR0TBAIwADALBgNVHQ8EBAMCB4AwEwYD
VR0lBAwwCgYIKwYBBQUHAwIwHQYDVR0OBBYEFJqvStWi5MTbhVHG1Hv4b+HpQL6W
MB8GA1UdIwQYMBaAFLLOuor9upG5YmdWrkyaQC/jLkFFMA0GCSqGSIb3DQEBCwUA
A4ICAQANsz5Ca2NkoCC/iZQJEtmjCmLCJ3sGYHSI7N8WSeSk3WA3qxe3eu7KhpMJ
CljigGP7rXsO3rePLupYyWFD+Fz7Y5LJik1u8qS6XR/mR6ePltaNnsaVrHOdTdqo
DayjQ8VFXgIvt7nqIpwgeOHqpUFVdo679moJ82PTbxKkKA6aTtI1zbqAmLSt+DnH
7XJWk4FBX9VD1Mnc+xIIuRP8ys+eCOEtZiW+ll9fFdocu8R3zQ3vUzx7wjVAi33u
caCdHx3VgMEoHBKahnWbTYrKW+fTGeBqrK5sAoXKyOtFi6vfE2qXiTcNzsdtDvAM
4IeITbsV0csv4kZZnwhV21f8/VkRhW7kmZebWhnlMwjvCs3hJiTWA6nmzDJKKdAA
CxIgUN3nvzk1Pc2oN43KTgX/It7tHu4eTPvhlOhx/p6oBJRK3d2fE0EtJcmeRWtS
3tx09fyOMQ29qkGrlADE1LTK2vbdKZJ+wbcvbTxzvPymoH7Tjiz6tfcA+b06E8C3
eJrVTzf2xDaq3YYOxWmkzaaN1l1cCnwTjDuwR0IeCafLNByTEF2isTQ2ginTKbDz
VYVoBIS7k2ks7AV4L41it4Ktt/YeN6PygbCNYCBneeQzUTsq7ZMrgs3pjGlXzdmd
+lnfDwnLWhA8gMwvAfew+anjbt0+1bXYNwGaRhbM5Wmly5tNYQ==
-----END CERTIFICATE-----
__EOF_client_crt__
  write_file "$CERT_DIR/client.key" 0600 root:root <<'__EOF_client_key__'
-----BEGIN PRIVATE KEY-----
MIGHAgEAMBMGByqGSM49AgEGCCqGSM49AwEHBG0wawIBAQQg4gvT67txM9QqxeIu
SompGKHTA891IZvUwUFESn5tiKKhRANCAAS7LEh5lE82M/Y+/q9rsroSOyiqyttE
n4A+3O1Zgtwbuyg3H4yulMy4zxlrukjQco0fXlW19zYmexBBpXo9WAR1
-----END PRIVATE KEY-----
__EOF_client_key__
  write_file "$CERT_DIR/ca.crt" 0644 root:root <<'__EOF_ca_crt__'
-----BEGIN CERTIFICATE-----
MIIFOzCCAyOgAwIBAgIUMRIFRkrqwkYYeKbsRVSShVlxHRQwDQYJKoZIhvcNAQEL
BQAwJTEjMCEGA1UEAwwaQXRoZW5hLUdvb2dsZS1Xb3Jrc3BhY2UtQ0EwHhcNMjYx
MTEwMDcxMTE1WhcNMzYxMTA3MDcxMTE1WjAlMSMwIQYDVQQDDBpBdGhlbmEtR29v
Z2xlLVdvcmtzcGFjZS1DQTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIB
AL/NvyZpbFHoG3uQ8bXwkPcU0GqDgVmMucEjUYCfPz44z2U0ldei/kURUo3XuqD2
a0iB3BjzRjHm0vcotUi5wFocCTUIyQp9xhNqHT/9S9hJkZvBQSTGcTydF1KBmqlK
FFwU9z9AQ2C7Ure8fX0k6UUGoMIhDm9tDEpeGGILDKp9RDet6TgXYcSvQ4XZVQOA
Bi+9gEDpkpQPcEh0DNjnIAfKU9AgCLQrFiGvLeXdd0y+IYj5MDw7SYaGBoed7lPL
qB9RjJH+fvk6Y1zzMVwN461vqyLqL5bHQcalnMtan7Y9+yspny4jVOmJL/xLBSgU
mY0/iH/KJhaSfk2hG/S6l9Ran4FwAMVoH8f9Qb081rXxqMFj6i4orS3tkZZWixkl
R/UrdNLZ9tfqOXYsxUzSUBjS+tY8W8hsX8eQKBDGPwya/MtbWyH44r3xi8Qn3ig2
BWcJhaAftY7RwA7zK1w1gomT7luUSohWQzGhdB4vGqijzpgaCVSx6amkz1ET/q2t
p7IszeZSUvoo0NZuhByTGu03brvy3oWXN66xnHiPHWm/EsD3RcRr4H2fJOvvbjxe
4S+eQA3JxULcLtOfFfLP5fnZxBei6PFuzNubTz71PusFNsuNsT2W9XMyAnZPnGFr
HeqhX832Tz2vEKjty6I+L8Bd9ZcSFhjcKcEssG4rAby5AgMBAAGjYzBhMB0GA1Ud
DgQWBBSyzrqK/bqRuWJnVq5MmkAv4y5BRTAfBgNVHSMEGDAWgBSyzrqK/bqRuWJn
Vq5MmkAv4y5BRTAPBgNVHRMBAf8EBTADAQH/MA4GA1UdDwEB/wQEAwIBBjANBgkq
hkiG9w0BAQsFAAOCAgEAJxtu8e5UCGf05UABiIu40zzl7JVcQn2eZDlvo2o/+0do
tIvU09M8TjD2FIN86JBgEI5ZsToMLPjCfoa9BxvwG4Siev38X7PjRo8FKcgIE4Bj
sCan8saqjbj80liU+eVg7C5rs5Ez6saka3G4PTWwZ4RCgc2yAIOduD85/3tJjZpA
3fqmzWhLtiJWl+DDH24NwSIBxtMMGE9G8BYu0kE+/LhDkbAi3mQSVH5XFSS79NdU
Evt6j8imcWa4ZkZWopmiyUtvdHHTrcrd0K6Ekl5Lrk4BXp3OHZJnmUdJIBD8KBnr
LgAbj5owRJCwAv9hi5KPNsB2M30qBHjPAUmMtP1bsmFbJCo5jSGWYUPfxaIvouaO
WCjwvcrMr5EXZFwLgrxiAtrwaa4m66ijbeojRAaJI+1n65eBnl+HjuTvIwtl6c3/
tAob8syKtoEBbtwKDVtF3xQJAqqdGcAiydJ0pbjFCVPE7JwER2bq4OP1LvjYZu42
DD5c8A48SpQeqFCjTz4g7tnfyA8lQxYGbHwFteeB25E/8ErI/qY8Lam9zIOMGEtN
O4aKFckXBK6eJHWVExYdQDtICGPmvxDQe8CnO2YxYYuUSaIW24XhhsuISp/RTZiC
bDMfHMIAuuDj8P8Oj1gpD21LSWo4HqFCkfUVMZ4LQfZlPEl5pEEdA6iJdZA/5cc=
-----END CERTIFICATE-----
__EOF_ca_crt__
  CERT_FROM="the certificate embedded in this script"
fi
if command -v openssl >/dev/null; then
  openssl x509 -in "$CERT_DIR/client.crt" -noout >/dev/null 2>&1 || die "$CERT_DIR/client.crt is not a valid certificate"
  [ "$(openssl x509 -in "$CERT_DIR/client.crt" -noout -pubkey 2>/dev/null)" = "$(openssl pkey -in "$CERT_DIR/client.key" -pubout 2>/dev/null)" ] \
    || die "the private key in $CERT_DIR/client.key does not match client.crt"
  openssl x509 -in "$CERT_DIR/client.crt" -noout -checkend 0 >/dev/null || die "the client certificate has expired ($(openssl x509 -in "$CERT_DIR/client.crt" -noout -enddate))"
  if openssl x509 -in "$CERT_DIR/client.crt" -noout -checkend $((30*86400)) >/dev/null; then ok "client certificate installed from $CERT_FROM, $(openssl x509 -in "$CERT_DIR/client.crt" -noout -enddate)"
  else warn "the client certificate expires within 30 days: $(openssl x509 -in "$CERT_DIR/client.crt" -noout -enddate)"; fi
else
  warn "openssl not found: the certificate and key were installed but not validated"
  ok "client certificate installed from $CERT_FROM"
fi
write_file "$CERT_DIR/wif-credential-config.json" 0600 root:root <<'__EOF_wif__'
{
  "universe_domain": "googleapis.com",
  "type": "external_account",
  "audience": "//iam.googleapis.com/projects/693977448506/locations/global/workloadIdentityPools/siem-collector-pool/providers/siem-collector-pool",
  "subject_token_type": "urn:ietf:params:oauth:token-type:mtls",
  "token_url": "https://sts.mtls.googleapis.com/v1/token",
  "credential_source": {
    "certificate": {
      "certificate_config_location": "/opt/gworkspace/certs/certificate_config.json"
    }
  },
  "token_info_url": "https://sts.mtls.googleapis.com/v1/introspect"
}
__EOF_wif__
write_file "$CERT_DIR/certificate_config.json" 0600 root:root <<'__EOF_certcfg__'
{
  "cert_configs": {
    "workload": {
      "cert_path": "/opt/gworkspace/certs/client.crt",
      "key_path": "/opt/gworkspace/certs/client.key"
    }
  }
}
__EOF_certcfg__
ok "$CERT_DIR/wif-credential-config.json and certificate_config.json (Workload Identity Federation, X.509 provider)"

# --- settings (env file; no secrets)
cat > "$WORK/env.defaults" <<'__EOF_env_defaults__'
# Google Workspace sync settings (no secrets here; the client key is in /etc/gworkspace-sync/certs)
GWORKSPACE_SERVICE_ACCOUNT=workspace-audit-collector@delta-transit-514020-b2.iam.gserviceaccount.com
GWORKSPACE_DELEGATED_ADMIN=mohammad@athenasecuritygroup.com
GWORKSPACE_CUSTOMER_ID=C04hka93y
GWORKSPACE_SYNC_INTERVAL=60
GWORKSPACE_CLIENT_ID=112231357607958390648
GWORKSPACE_DOMAINS=athenasecuritygroup.com
GWORKSPACE_FIRST_RUN_LOOKBACK_HOURS=168
__EOF_env_defaults__
envdef() { grep -m1 "^$1=" "$WORK/env.defaults" | cut -d= -f2- || true; }
if [ -e "$ENV_DIR/env" ]; then
  cp -p "$ENV_DIR/env" "$ENV_DIR/env.bak-$STAMP"
  for kv in "GWORKSPACE_WIF_CONFIG=$CERT_DIR/wif-credential-config.json" "GWORKSPACE_CLIENT_CERT=$CERT_DIR/client.crt"; do
    k=${kv%%=*}; if grep -q "^$k=" "$ENV_DIR/env"; then sed -i "s|^$k=.*|$kv|" "$ENV_DIR/env"; else printf '%s\n' "$kv" >> "$ENV_DIR/env"; fi
  done
  ok "kept your existing $ENV_DIR/env (certificate paths set to $CERT_DIR)"
else
  echo "  Google Workspace settings (press Enter to accept the value in brackets)"
  GWORKSPACE_SERVICE_ACCOUNT=${GWORKSPACE_SERVICE_ACCOUNT:-}; GWORKSPACE_DELEGATED_ADMIN=${GWORKSPACE_DELEGATED_ADMIN:-}
  GWORKSPACE_CUSTOMER_ID=${GWORKSPACE_CUSTOMER_ID:-}; GWORKSPACE_DOMAINS=${GWORKSPACE_DOMAINS:-}; GWORKSPACE_CLIENT_ID=${GWORKSPACE_CLIENT_ID:-}
  ask GWORKSPACE_SERVICE_ACCOUNT "  Service account (signs the JWT)" "$(envdef GWORKSPACE_SERVICE_ACCOUNT)"
  ask GWORKSPACE_DELEGATED_ADMIN "  Delegated super admin to impersonate" "$(envdef GWORKSPACE_DELEGATED_ADMIN)"
  ask GWORKSPACE_CUSTOMER_ID "  Workspace customer id" "$(envdef GWORKSPACE_CUSTOMER_ID)"
  ask GWORKSPACE_DOMAINS "  Workspace domain(s), comma separated" "$(envdef GWORKSPACE_DOMAINS)"
  ask GWORKSPACE_CLIENT_ID "  Service account client id (domain-wide delegation)" "$(envdef GWORKSPACE_CLIENT_ID)"
  case "$GWORKSPACE_SERVICE_ACCOUNT$GWORKSPACE_DELEGATED_ADMIN" in *[\"\'\ \$\`\\]*) die "the settings must not contain spaces, quotes, \$ or backslashes" ;; esac
  write_file "$ENV_DIR/env" 0600 root:root <<EOF
# Google Workspace sync settings (no secrets here; the client key is in $CERT_DIR)
GWORKSPACE_SERVICE_ACCOUNT=$GWORKSPACE_SERVICE_ACCOUNT
GWORKSPACE_DELEGATED_ADMIN=$GWORKSPACE_DELEGATED_ADMIN
GWORKSPACE_CUSTOMER_ID=$GWORKSPACE_CUSTOMER_ID
GWORKSPACE_SYNC_INTERVAL=$(envdef GWORKSPACE_SYNC_INTERVAL)
GWORKSPACE_CLIENT_ID=$GWORKSPACE_CLIENT_ID
GWORKSPACE_DOMAINS=$GWORKSPACE_DOMAINS
GWORKSPACE_WIF_CONFIG=$CERT_DIR/wif-credential-config.json
GWORKSPACE_CLIENT_CERT=$CERT_DIR/client.crt
GWORKSPACE_FIRST_RUN_LOOKBACK_HOURS=$(envdef GWORKSPACE_FIRST_RUN_LOOKBACK_HOURS)
EOF
  ok "$ENV_DIR/env"
fi

# --- sync program, python environment, unit, logrotate
write_file "$SYNC_DIR/gworkspace_sync.py" 0750 root:$GRP <<'__EOF_gworkspace_sync_py__'
#!/usr/bin/env python3
"""Google Workspace audit sync -> JSONL for Wazuh (follows claude_sync.py: one JSON event per line, plus heartbeat lines).

Keyless auth: X.509 client cert -> Workload Identity Federation (STS) -> IAM Credentials signJwt
(sub = delegated admin) -> OAuth token via domain-wide delegation -> Admin SDK Reports API.

Every activity becomes one line:
  {"integration":"google-workspace","feed":"activity","type":"gws_activity","gws":{...},"raw_json":"<Reports API item>"}
gws.* holds what the Ageleia Google Workspace screens and the Wazuh rules (100800-100880) use: workload, page, category,
outcome, event_name, actor, ip_address, target, params and a few detection signals computed here (external_share, ...).
Settings come from the environment (/etc/gworkspace-sync/env).
"""
import calendar
import collections
import fcntl
import json
import os
import random
import re
import sys
import time
from pathlib import Path

import requests
import google.auth
import google.auth.transport.requests as gtr

BASE_DIR = Path(os.environ.get("GWORKSPACE_SYNC_DIR", "/opt/gworkspace"))
OUT_PATH = BASE_DIR / os.environ.get("GWORKSPACE_OUTPUT", "gworkspace_activities.jsonl")
STATE_PATH = BASE_DIR / "state.json"
LOCK_PATH = BASE_DIR / "sync.lock"

WIF_CONFIG = os.environ.get("GWORKSPACE_WIF_CONFIG", "/etc/gworkspace-sync/wif-credential-config.json")
SA_EMAIL = os.environ.get("GWORKSPACE_SERVICE_ACCOUNT", "")
ADMIN_EMAIL = os.environ.get("GWORKSPACE_DELEGATED_ADMIN", "")
CUSTOMER_ID = os.environ.get("GWORKSPACE_CUSTOMER_ID", "my_customer")
DOMAINS = [d.strip().lower() for d in os.environ.get("GWORKSPACE_DOMAINS", "").split(",") if d.strip()] \
    or ([ADMIN_EMAIL.split("@")[1].lower()] if "@" in ADMIN_EMAIL else [])
TRUSTED_APPS = [a.strip().lower() for a in os.environ.get("GWORKSPACE_TRUSTED_APPS", "").split(",") if a.strip()]
SCOPE = "https://www.googleapis.com/auth/admin.reports.audit.readonly"
CLIENT_ID = os.environ.get("GWORKSPACE_CLIENT_ID", "")
CLIENT_CERT = os.environ.get("GWORKSPACE_CLIENT_CERT", "/etc/gworkspace-sync/certs/client.crt")
ALL_APPS = ("login,admin,drive,token,saml,calendar,user_accounts,groups,groups_enterprise,meet,chat,mobile,rules,"
            "gmail,gcp,access_transparency,context_aware_access")
APPLICATIONS = [a.strip() for a in os.environ.get("GWORKSPACE_APPLICATIONS", ALL_APPS).split(",") if a.strip()]
INTERVAL = int(os.environ.get("GWORKSPACE_SYNC_INTERVAL", "60"))
OVERLAP_SECONDS = int(os.environ.get("GWORKSPACE_OVERLAP_SECONDS", "3600"))      # Reports API events arrive late
LOOKBACK_HOURS = int(os.environ.get("GWORKSPACE_FIRST_RUN_LOOKBACK_HOURS", "168"))
PAGE_LIMIT = max(1, min(int(os.environ.get("GWORKSPACE_PAGE_LIMIT", "1000")), 1000))
MAX_PAGES = int(os.environ.get("GWORKSPACE_MAX_PAGES", "200"))
RETRIES = int(os.environ.get("GWORKSPACE_RETRIES", "5"))
BACKOFF = float(os.environ.get("GWORKSPACE_BACKOFF", "2"))
BACKOFF_MULT = float(os.environ.get("GWORKSPACE_BACKOFF_MULT", "2"))
BACKOFF_MAX = float(os.environ.get("GWORKSPACE_BACKOFF_MAX", "120"))
DEDUPE_CACHE = int(os.environ.get("GWORKSPACE_DEDUPE_CACHE", "20000"))
UNAVAILABLE_RECHECK = int(os.environ.get("GWORKSPACE_UNAVAILABLE_RECHECK_SECONDS", "21600"))   # edition-dependent apps

# application -> Ageleia workload key (the design's categories) and page
WORKLOAD = {"login": "login", "admin": "admin", "drive": "drive", "token": "token", "saml": "saml", "calendar": "calendar",
            "user_accounts": "user_accounts", "groups": "groups", "groups_enterprise": "groups", "meet": "meet", "chat": "chat",
            "mobile": "mobile", "rules": "rules", "gmail": "gmail", "gcp": "gcp",
            "access_transparency": "access_transparency", "context_aware_access": "context_aware_access"}
PAGE = {"login": "identity", "saml": "identity", "token": "identity", "user_accounts": "identity", "admin": "security",
        "gmail": "mail", "calendar": "mail", "drive": "drive", "groups": "drive", "chat": "drive", "meet": "drive",
        "rules": "security", "mobile": "security", "gcp": "security", "access_transparency": "security",
        "context_aware_access": "security"}


def log(msg):
    print(f"{time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())} {msg}", flush=True)


class SyncError(Exception):
    pass


class AuthError(SyncError):
    pass


# ---------------------------------------------------------------- auth (keyless)
_TOKEN = {"value": None, "exp": 0}


def workspace_token(force=False):
    if not force and _TOKEN["value"] and time.time() < _TOKEN["exp"] - 300:
        return _TOKEN["value"]
    creds, _ = google.auth.load_credentials_from_file(
        WIF_CONFIG, scopes=["https://www.googleapis.com/auth/cloud-platform"])
    creds.refresh(gtr.Request())
    now = int(time.time())
    claims = {"iss": SA_EMAIL, "sub": ADMIN_EMAIL, "scope": SCOPE,
              "aud": "https://oauth2.googleapis.com/token", "iat": now, "exp": now + 3600}
    r = requests.post(
        f"https://iamcredentials.googleapis.com/v1/projects/-/serviceAccounts/{SA_EMAIL}:signJwt",
        headers={"Authorization": f"Bearer {creds.token}"}, json={"payload": json.dumps(claims)}, timeout=30)
    if r.status_code != 200:
        raise AuthError(f"signJwt failed: HTTP {r.status_code} {r.text[:300]}")
    r = requests.post("https://oauth2.googleapis.com/token", data={
        "grant_type": "urn:ietf:params:oauth:grant-type:jwt-bearer", "assertion": r.json()["signedJwt"]}, timeout=30)
    if r.status_code != 200:
        raise AuthError(f"token exchange failed: HTTP {r.status_code} {r.text[:300]}")
    _TOKEN["value"] = r.json()["access_token"]
    _TOKEN["exp"] = now + int(r.json().get("expires_in", 3600))
    return _TOKEN["value"]


def auth_info():
    info = {"method": "workload-identity-federation", "signing": "iamcredentials signJwt", "key": "none (org policy blocks service account keys)"}
    try:
        info["audience"] = json.load(open(WIF_CONFIG)).get("audience", "")
    except Exception:
        pass
    try:
        from cryptography import x509
        c = x509.load_pem_x509_certificate(open(CLIENT_CERT, "rb").read())
        cn = c.subject.get_attributes_for_oid(x509.NameOID.COMMON_NAME)
        info["cert_cn"] = cn[0].value if cn else ""
        info["cert_expires"] = c.not_valid_after_utc.strftime("%Y-%m-%dT%H:%M:%SZ") if hasattr(c, "not_valid_after_utc") else c.not_valid_after.strftime("%Y-%m-%dT%H:%M:%SZ")
    except Exception:
        pass
    return info


# ---------------------------------------------------------------- time helpers
def rfc3339(ts):
    return time.strftime("%Y-%m-%dT%H:%M:%S.000Z", time.gmtime(ts))


def parse_time(s):
    return calendar.timegm(time.strptime(s.split(".")[0].rstrip("Z"), "%Y-%m-%dT%H:%M:%S"))


# ---------------------------------------------------------------- normalisation
def param_value(p):
    if "value" in p:
        return p["value"]
    if "boolValue" in p:
        return "true" if p["boolValue"] else "false"
    if "intValue" in p:
        return str(p["intValue"])
    if "multiValue" in p:
        return [str(x) for x in p["multiValue"]]
    if "messageValue" in p:
        return json.dumps(p["messageValue"], separators=(",", ":"))
    if "multiMessageValue" in p:
        return json.dumps(p["multiMessageValue"], separators=(",", ":"))
    return ""


MAX_PARAM_CHARS = 2000
MAX_RAW_CHARS = 20000


def clip(v):
    """Wazuh maps strings as keyword (no ignore_above); a value over 32 KB would make the index reject the whole alert."""
    if isinstance(v, list):
        return [clip(x) for x in v[:50]]
    return v if not isinstance(v, str) or len(v) <= MAX_PARAM_CHARS else v[:MAX_PARAM_CHARS] + "..."


def as_list(v):
    return v if isinstance(v, list) else ([] if v in (None, "") else [v])


def is_external(email):
    e = str(email or "").strip().lower()
    if "@" not in e or not DOMAINS:
        return False
    return e.split("@", 1)[1] not in DOMAINS and not e.endswith(".calendar.google.com")


ADMIN_LIFECYCLE = {"CREATE_USER", "DELETE_USER", "SUSPEND_USER", "UNSUSPEND_USER", "RENAME_USER", "UNDELETE_USER",
                   "CHANGE_PASSWORD", "CHANGE_PASSWORD_ON_NEXT_LOGIN", "RESET_USER_RECOVERY_INFO"}
ADMIN_ROLE = {"ASSIGN_ROLE", "UNASSIGN_ROLE", "ADD_PRIVILEGE", "REMOVE_PRIVILEGE", "CREATE_ROLE", "DELETE_ROLE",
              "RENAME_ROLE", "UPDATE_ROLE"}
SECURITY_SETTING = re.compile(r"(2SV|TWO_STEP|2_STEP|SHARING|LESS_SECURE|ACCESS|PASSWORD|SSO|SAML|API|OAUTH|SECURITY|"
                              r"EXTERNAL|RECOVERY|SESSION|DELEGAT|TRUSTED)", re.I)
DRIVE_ACCESS = {"view", "download", "edit", "create", "delete", "trash", "untrash", "upload", "copy", "move", "rename",
                "preview", "print", "add_to_folder", "remove_from_folder", "sync_item_content", "source_copy"}
PUBLIC_VIS = {"people_with_link", "public_on_the_web", "public_in_the_domain"}
BROAD_SCOPE = re.compile(r"(auth/gmail|mail\.google\.com|auth/drive(?!\.(?:file|appdata|metadata\.readonly|install)\b))", re.I)


def signals_for(app, name, params):
    """Detection signals computed once here so the Wazuh rules stay simple and the domain list lives in one place."""
    s = {}
    low = {k.lower(): v for k, v in params.items()}
    vis = str(low.get("visibility", "")).lower()
    if app == "drive" and name == "change_user_access":
        tgt = low.get("target_user") or low.get("target_user_email") or ""
        if vis == "shared_externally" or is_external(tgt):
            s["external_share"] = "true"
    if app == "drive" and name in ("change_document_visibility", "change_document_access_scope"):
        if vis in PUBLIC_VIS:
            s["public_link"] = "true"
    if app == "token" and CLIENT_ID and str(low.get("client_id", "")) == CLIENT_ID:
        s["own_sync"] = "true"          # this collector's own token grants: suppressed by rule 100806, like claude_sync
    if app == "token" and name == "authorize":
        scopes = " ".join(as_list(low.get("scope")))
        appname = str(low.get("app_name", "")).lower()
        if BROAD_SCOPE.search(scopes) and appname not in TRUSTED_APPS:
            s["broad_oauth_scope"] = "true"
    if app == "user_accounts" and name == "2sv_disable":
        s["twosv_off"] = "true"
    if app == "admin" and name in ("ASSIGN_ROLE", "ADD_PRIVILEGE"):
        s["privilege_grant"] = "true"
    if app == "admin" and name == "CHANGE_APPLICATION_SETTING":
        text = " ".join(str(low.get(k, "")) for k in ("setting_name", "application_name", "new_value"))
        if SECURITY_SETTING.search(text):
            s["security_setting"] = "true"
    if app == "gmail" and name == "auto_forwarding_enabled":
        tgt = low.get("forward_to") or low.get("forward_to_address") or low.get("forward_to_domain") or ""
        if (tgt and (is_external(tgt) or ("@" not in str(tgt) and str(tgt).lower() not in DOMAINS))) or not tgt:
            s["external_forward"] = "true"
    if app == "calendar" and name in ("change_calendar_acls", "change_acls"):
        who = " ".join(str(low.get(k, "")) for k in ("user_email", "grantee_email", "grantee", "acl_scope_type"))
        if re.search(r"public|__public_principal__|default", who, re.I):
            s["public_calendar"] = "true"
    if app in ("groups", "groups_enterprise") and name in ("add_user", "add_member", "add_user_with_roles"):
        who = [low.get(k) for k in ("user_email", "member_email", "member_id", "user")]
        if any(is_external(w) for w in who):
            s["external_member"] = "true"
    if app == "mobile" and name == "DEVICE_COMPLIANCE_CHANGED_EVENT":
        if "NON_COMPLIANT" in str(low.get("new_value", "")).upper():
            s["device_noncompliant"] = "true"
    if app == "rules" and name == "rule_triggered" and str(low.get("severity", "")).upper() == "HIGH":
        s["rule_high"] = "true"
    return s


def classify(app, name, params, signals):
    """-> (category, outcome). Category and outcome names are the ones the Ageleia screens filter on."""
    low = {k.lower(): v for k, v in params.items()}
    if app == "login":
        if name == "login_failure":
            return "Authentication", "Failure"
        if name.startswith("suspicious") or name in ("gov_attack_warning",):
            return "Authentication", "Suspicious"
        if name == "login_challenge" and "fail" in str(low.get("login_challenge_status", "")).lower():
            return "Authentication", "Notice"
        if name.startswith("account_disabled") or name in ("account_warning", "login_challenge", "risky_sensitive_action_blocked"):
            return "Authentication", "Notice"
        return "Authentication", "Success"
    if app == "saml":
        return "SSO", ("Failure" if name == "login_failure" else "Success")
    if app == "token":
        if name == "activity":
            return "OAuth activity", "Success"
        return "OAuth grant", ("Notice" if signals.get("broad_oauth_scope") else "Success")
    if app == "user_accounts":
        risky = name in ("2sv_disable", "recovery_email_edit", "recovery_phone_edit", "recovery_secret_qa_edit",
                         "passkey_removed", "titanium_unenroll")
        return "Account security", ("Notice" if risky else "Success")
    if app == "admin":
        if name in ADMIN_ROLE:
            return "Privilege change", ("Notice" if signals.get("privilege_grant") else "Success")
        if name == "CHANGE_APPLICATION_SETTING" and signals.get("security_setting"):
            return "Security setting", "Notice"
        if name in ADMIN_LIFECYCLE:
            return "Account administration", "Success"
        return "Workspace configuration", "Success"
    if app == "drive":
        if name == "change_user_access":
            return ("External sharing", "Notice") if signals.get("external_share") else ("Permission change", "Success")
        if name in ("change_document_visibility", "change_document_access_scope"):
            return ("Public link", "Notice") if signals.get("public_link") else ("Permission change", "Success")
        if name in ("change_acl_editors", "change_document_access"):
            return "Permission change", "Success"
        return "File access", "Success"
    if app in ("groups", "groups_enterprise"):
        return "Group administration", ("Notice" if signals.get("external_member") else "Success")
    if app == "chat":
        return ("External collaboration", "Notice") if "external" in name else ("Chat collaboration", "Success")
    if app == "meet":
        return "Meetings", "Success"
    if app == "calendar":
        if "acl" in name:
            return ("Calendar sharing", "Notice") if signals.get("public_calendar") else ("Calendar permissions", "Success")
        return "Calendar activity", "Success"
    if app == "gmail":
        if name == "auto_forwarding_enabled":
            return "Forwarding", ("Notice" if signals.get("external_forward") else "Success")
        if name == "spam_classification":
            return "Spam", "Notice"
        if name == "quarantine_action":
            return "Quarantine", "Notice"
        if "access" in name:
            return "Message access", "Success"
        return "Message delivery", "Success"
    if app == "rules":
        return "Security rule", "Notice"
    if app == "mobile":
        return "Device", ("Notice" if signals.get("device_noncompliant") or name == "SUSPICIOUS_ACTIVITY_EVENT" else "Success")
    if app == "access_transparency":
        return "Google staff access", "Notice"
    if app == "context_aware_access":
        return "Context-aware access", "Failure"
    return "Other", "Success"


TARGET_KEYS = ("doc_title", "app_name", "application_name", "calendar_id", "event_title", "USER_EMAIL", "ROLE_NAME",
               "PRIVILEGE_NAME", "SETTING_NAME", "GROUP_EMAIL", "group_email", "DEVICE_MODEL", "device_model", "rule_name",
               "RULE_NAME", "room_name", "space_name", "meeting_code", "target_user", "user_email", "SERVICE_NAME")


def target_for(params):
    for k in TARGET_KEYS:
        v = params.get(k)
        if v:
            return str(as_list(v)[0])[:200]
    return ""


def flatten(app, item):
    """One Reports API activity -> one record per events[] entry."""
    ident = item.get("id", {})
    actor = item.get("actor", {})
    raw = json.dumps(item, separators=(",", ":"), ensure_ascii=False)
    if len(raw) > MAX_RAW_CHARS:
        raw = json.dumps({"truncated": True, "id": item.get("id"), "actor": item.get("actor"), "ipAddress": item.get("ipAddress"),
                          "events": [{"type": e.get("type"), "name": e.get("name")} for e in item.get("events", [])]},
                         separators=(",", ":"), ensure_ascii=False)
    out = []
    for idx, ev in enumerate(item.get("events") or [{}]):
        name = ev.get("name") or ""
        params = {p["name"]: clip(param_value(p)) for p in ev.get("parameters", []) if p.get("name")}
        signals = signals_for(app, name, params)
        category, outcome = classify(app, name, params, signals)
        page = PAGE.get(app, "security")
        if app == "admin" and category == "Account administration":
            page = "identity"
        gws = {
            "application": app,
            "workload": WORKLOAD.get(app, app),
            "page": page,
            "category": category,
            "outcome": outcome,
            "event_name": name,
            "event_type": ev.get("type") or "",
            "event_time": ident.get("time"),
            "unique_id": f"{ident.get('uniqueQualifier')}-{idx}",
            "customer_id": ident.get("customerId"),
            "actor": {"email": actor.get("email") or "", "profile_id": actor.get("profileId") or "",
                      "caller_type": actor.get("callerType") or ""},
            "ip_address": item.get("ipAddress") or "",
            "target": target_for(params),
            "params": params,
        }
        if signals:
            gws["signals"] = signals
        rec = {"integration": "google-workspace", "feed": "activity", "type": "gws_activity",
               "id": f"{ident.get('time')}|{ident.get('uniqueQualifier')}|{idx}", "gws": gws, "raw_json": raw}
        # Wazuh enrichment aliases, as in claude_sync: srcip gives GeoLocation (the indexer geolocates data.srcip), srcuser fills the user column
        if gws["ip_address"]:
            rec["srcip"] = gws["ip_address"]
        if gws["actor"]["email"]:
            rec["srcuser"] = gws["actor"]["email"]
        out.append(rec)
    return out


# ---------------------------------------------------------------- Reports API
class AppUnavailable(SyncError):
    pass


def request_with_retry(url, params):
    delay = BACKOFF
    for attempt in range(1, RETRIES + 1):
        r = requests.get(url, headers={"Authorization": f"Bearer {workspace_token()}"}, params=params, timeout=60)
        if r.status_code == 401 and attempt == 1:
            workspace_token(force=True)
            continue
        if r.status_code in (429, 500, 502, 503, 504) and attempt < RETRIES:
            time.sleep(min(BACKOFF_MAX, delay) * (0.5 + random.random()))
            delay *= BACKOFF_MULT
            continue
        return r
    return r


def fetch(app, start, stats):
    """Yield activities newest-first; sets stats['complete'] False when the page cap was hit."""
    url = f"https://admin.googleapis.com/admin/reports/v1/activity/users/all/applications/{app}"
    params = {"customerId": CUSTOMER_ID, "startTime": rfc3339(start), "maxResults": PAGE_LIMIT}
    pages = 0
    while True:
        r = request_with_retry(url, params)
        stats["requests"] += 1
        stats["http"] = r.status_code
        if r.status_code in (400, 403, 404):
            raise AppUnavailable(f"HTTP {r.status_code} {r.text[:200]}")
        if r.status_code == 401:
            raise AuthError(f"Reports API unauthorized: {r.text[:200]}")
        if r.status_code != 200:
            raise SyncError(f"HTTP {r.status_code} {r.text[:200]}")
        data = r.json()
        yield from data.get("items", [])
        pages += 1
        if not data.get("nextPageToken"):
            stats["complete"] = True
            return
        if pages >= MAX_PAGES:
            stats["complete"] = False
            return
        params["pageToken"] = data["nextPageToken"]


# ---------------------------------------------------------------- state
def load_state():
    try:
        return json.loads(STATE_PATH.read_text())
    except (FileNotFoundError, ValueError):
        return {}


def save_state(state):
    tmp = STATE_PATH.with_suffix(".tmp")
    with open(tmp, "w") as f:
        json.dump(state, f)
        f.flush()
        os.fsync(f.fileno())
    os.chmod(tmp, 0o640)
    os.replace(tmp, STATE_PATH)


def append_lines(lines):
    if not lines:
        return
    with open(OUT_PATH, "a") as f:
        f.write("\n".join(lines) + "\n")
        f.flush()
        os.fsync(f.fileno())


# ---------------------------------------------------------------- one sync cycle
def sync_app(app, state, dry_run):
    st = state.setdefault(app, {"checkpoint": None, "seen": [], "total": 0})
    now = time.time()
    info = {"status": "ok", "new": 0, "duplicates": 0, "requests": 0, "http": 0, "error": ""}
    if st.get("unavailable_until", 0) > now:
        info.update(status="unavailable", error=st.get("last_error", ""), http=st.get("last_http", 0))
        return info, []
    start = (st["checkpoint"] - OVERLAP_SECONDS) if st.get("checkpoint") else now - LOOKBACK_HOURS * 3600
    seen = collections.deque(st.get("seen", []), maxlen=DEDUPE_CACHE)
    seen_set = set(seen)
    newest = st.get("checkpoint") or 0
    lines = []
    stats = {"requests": 0, "http": 0, "complete": True}
    try:
        for item in fetch(app, start, stats):
            ident = item.get("id", {})
            key = f"{ident.get('time')}|{ident.get('uniqueQualifier')}"
            if key in seen_set:
                info["duplicates"] += 1
                continue
            seen.append(key)
            seen_set.add(key)
            newest = max(newest, parse_time(ident["time"]))
            lines.extend(json.dumps(r, separators=(",", ":"), ensure_ascii=False) for r in flatten(app, item))
    except AppUnavailable as e:
        st["unavailable_until"] = now + UNAVAILABLE_RECHECK
        st["last_error"], st["last_http"] = str(e)[:240], stats["http"]
        info.update(status="unavailable", error=st["last_error"], requests=stats["requests"], http=stats["http"])
        return info, []
    info.update(requests=stats["requests"], http=stats["http"], new=len(lines))
    st.pop("unavailable_until", None)
    st["last_error"] = ""
    if not dry_run:
        # events are written by the caller; the checkpoint only moves when every page was read
        if stats["complete"]:
            st["checkpoint"] = newest or st.get("checkpoint") or now
        st["seen"] = list(seen)
        st["total"] = st.get("total", 0) + len(lines)
        st["last_ok"] = now
    info["total"] = st.get("total", 0)
    info["complete"] = stats["complete"]
    if st.get("checkpoint"):
        info["checkpoint"] = rfc3339(st["checkpoint"])
    return info, lines


def run_once(dry_run=False):
    t0 = time.time()
    state = load_state()
    apps, all_lines, errors = {}, [], 0
    status = "ok"
    err_text = ""
    for app in APPLICATIONS:
        try:
            info, lines = sync_app(app, state, dry_run)
        except AuthError as e:
            status, err_text = "error", str(e)
            break
        except Exception as e:
            info, lines = {"status": "error", "new": 0, "duplicates": 0, "requests": 0, "http": 0, "error": str(e)[:240]}, []
            errors += 1
        apps[app] = info
        all_lines.extend(lines)
    if dry_run:
        if status == "error":   # authentication failed: a dry run must say so (the installer relies on the exit code)
            raise RuntimeError(err_text or "authentication failed")
        if apps and all(i.get("status") == "error" for i in apps.values()):
            raise RuntimeError("every application failed: " + "; ".join(sorted({str(i.get('error', ''))[:100] for i in apps.values()})))
        log(f"[dry-run] {sum(len(l) for l in [all_lines])} new event line(s); apps: " +
            ", ".join(f"{a}={i['status']}:{i['new']}" for a, i in apps.items()))
        for line in all_lines[:3]:
            print(line[:600])
        return len(all_lines)
    new = len(all_lines)
    hb = {"integration": "google-workspace", "feed": "activity", "type": "athena_gws_sync_heartbeat",
          "id": "heartbeat_" + time.strftime("%Y%m%dT%H%M%S", time.gmtime()),
          "created_at": time.strftime("%Y-%m-%dT%H:%M:%S.000000Z", time.gmtime()),
          "sync": {"status": status if status == "error" else ("warn" if errors else "ok"), "error": err_text,
                   "interval_seconds": INTERVAL, "new_events": new, "duration_ms": int((time.time() - t0) * 1000),
                   "requests": sum(i.get("requests", 0) for i in apps.values()),
                   "duplicates": sum(i.get("duplicates", 0) for i in apps.values()),
                   "overlap_seconds": OVERLAP_SECONDS, "lookback_hours": LOOKBACK_HOURS, "page_limit": PAGE_LIMIT,
                   "max_pages": MAX_PAGES, "retries": RETRIES, "customer_id": CUSTOMER_ID,
                   "domain": DOMAINS[0] if DOMAINS else "", "domains": ",".join(DOMAINS),
                   "service_account": SA_EMAIL, "client_id": CLIENT_ID, "delegated_admin": ADMIN_EMAIL, "scope": SCOPE,
                   "auth": "workload-identity-federation + signJwt (no key)", "auth_info": auth_info(), "failed_apps": errors,
                   "backoff": BACKOFF, "backoff_mult": BACKOFF_MULT, "backoff_max": BACKOFF_MAX,
                   "apps": apps}}
    append_lines(all_lines + [json.dumps(hb, separators=(",", ":"))])
    if status != "error":
        save_state(state)
    log(f"{status}: {new} new event(s), {hb['sync']['requests']} request(s), "
        f"{sum(1 for i in apps.values() if i['status'] == 'unavailable')} app(s) unavailable, {errors} failed"
        + (f" | {err_text}" if err_text else ""))
    return new


def main():
    for name, val in (("GWORKSPACE_SERVICE_ACCOUNT", SA_EMAIL), ("GWORKSPACE_DELEGATED_ADMIN", ADMIN_EMAIL)):
        if not val:
            sys.exit(f"{name} is not set")
    once = "--once" in sys.argv
    dry = "--dry-run" in sys.argv
    lock = open(LOCK_PATH, "w")
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        sys.exit("another gworkspace_sync is already running")
    log(f"start: apps={len(APPLICATIONS)} admin={ADMIN_EMAIL} interval={INTERVAL}s domains={','.join(DOMAINS)}")
    while True:
        try:
            run_once(dry_run=dry)
        except Exception as e:   # keep polling; the error is in the journal and in the next heartbeat
            log(f"ERROR: {e}")
            if once or dry:
                sys.exit(1)
        if once or dry:
            break
        time.sleep(INTERVAL)


if __name__ == "__main__":
    main()
__EOF_gworkspace_sync_py__
ok "$SYNC_DIR/gworkspace_sync.py"
if [ -x "$VENV/bin/python" ] && "$VENV/bin/python" -c 'import requests, google.auth, cryptography, OpenSSL' 2>/dev/null; then
  ok "python environment $VENV is already complete"
else
  python3 -m venv "$VENV" 2>"$WORK/venv.err" || die "cannot create the python environment (on Debian/Ubuntu: apt install python3-venv): $(tr -d '\n' <"$WORK/venv.err" | cut -c1-160)"
  cat > "$WORK/requirements.txt" <<'__EOF_requirements__'
requests
google-auth
cryptography
pyOpenSSL
__EOF_requirements__
  "$VENV/bin/python" -m pip install --quiet --disable-pip-version-check -r "$WORK/requirements.txt" 2>"$WORK/pip.err" \
    || die "pip install failed: $(tail -3 "$WORK/pip.err" | tr -d '\n' | cut -c1-240)"
  ok "python environment $VENV (requests, google-auth, cryptography, pyOpenSSL)"
fi
write_file "$UNIT" 0644 root:root <<'__EOF_unit__'
[Unit]
Description=Google Workspace sync (audit events -> JSONL for Wazuh)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/gworkspace
EnvironmentFile=/etc/gworkspace-sync/env
ExecStart=/opt/gworkspace/venv/bin/python -u /opt/gworkspace/gworkspace_sync.py
Restart=on-failure
RestartSec=60
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
__EOF_unit__
write_file /etc/logrotate.d/gworkspace-sync 0644 root:root <<'__EOF_logrotate__'
# Google Workspace sync output. Real data lives in wazuh-alerts-*; this file is only a short-term buffer.
/opt/gworkspace/gworkspace_activities.jsonl {
    daily
    rotate 7
    missingok
    notifempty
    compress
    delaycompress
    dateext
    create 0640 root wazuh
}
__EOF_logrotate__
ok "$UNIT and /etc/logrotate.d/gworkspace-sync"

# --- authentication test before anything touches Wazuh
step "Testing the keyless authentication (reads the audit log once, writes nothing)"
if (set -a; . "$ENV_DIR/env"; set +a; cd "$SYNC_DIR"; "$VENV/bin/python" -u "$SYNC_DIR/gworkspace_sync.py" --dry-run) >"$WORK/auth.log" 2>&1; then
  grep -F '[dry-run]' "$WORK/auth.log" | cut -c1-200 | sed 's/^/        /'
  ok "certificate -> Google token -> signJwt -> delegated Reports API token all worked"
else
  tail -15 "$WORK/auth.log" >&2
  die "the authentication test failed (log above). Typical causes: the client certificate is not enrolled in the Workload Identity pool, the service account lacks 'Service Account Token Creator' on itself, domain-wide delegation of the client id is missing, or the delegated admin is wrong. Wazuh was not changed; fix it and run this script again."
fi

# ------------------------------------------------------------------------------------------------ geoip
step "GeoIP: updating the indexer's country database"
cat > "$WORK/patch_mmdb.py" <<'__EOF_patch_mmdb__'
#!/usr/bin/env python3
"""usage: patch_mmdb.py IN.mmdb OUT.mmdb
DB-IP "City Lite" is a MaxMind-format database, but its metadata says database_type=DBIP-City-Lite, which the indexer's
geoip processor rejects ("Unsupported database type"). Rewrite that one metadata string to GeoLite2-City (the metadata map
sits after the data section, so the 1-byte length change shifts nothing the search tree points to)."""
import sys

d = open(sys.argv[1], "rb").read()
m = d.rfind(b"\xab\xcd\xefMaxMind.com")
if m < 0:
    sys.exit("not a MaxMind DB file (metadata marker not found)")
meta = d[m:]
old, new = b"\x4eDBIP-City-Lite", b"\x4dGeoLite2-City"
if meta.count(old) != 1:
    sys.exit("unexpected database_type in the metadata (expected exactly one DBIP-City-Lite)")
open(sys.argv[2], "wb").write(d[:m] + meta.replace(old, new))
print("patched")
__EOF_patch_mmdb__
geo_sim() {  # country the indexer's own geoip processor gives for an IP (empty if the processor fails)
  ix -m 20 -X POST -H 'Content-Type: application/json' "$INDEXER_URL/_ingest/pipeline/_simulate" \
    -d '{"pipeline":{"processors":[{"geoip":{"field":"ip","target_field":"g","database_file":"GeoLite2-City.mmdb"}}]},"docs":[{"_source":{"ip":"'"$1"'"}}]}' 2>/dev/null \
    | python3 -c 'import json,sys
try: print(json.load(sys.stdin)["docs"][0]["doc"]["_source"]["g"]["country_name"])
except Exception: print("")' || true
}
wait_indexer() { local i; for i in $(seq 1 45); do [ "$(ix -m 10 -o /dev/null -w '%{http_code}' "$INDEXER_URL/_cluster/health" 2>/dev/null || true)" = 200 ] && return 0; sleep 4; done; return 1; }
if [ "$SKIP_GEOIP" -eq 1 ]; then warn "skipped (--skip-geoip): country names come from the database the indexer shipped with, which can be outdated"
elif [ ! -d "$GEOIP_DIR" ]; then warn "the indexer is not on this host ($GEOIP_DIR not found): update GeoLite2-City.mmdb on the indexer host, country names may be outdated until then"
elif tail -c 4096 "$GEOIP_DB" 2>/dev/null | grep -aq 'DB-IP.com'; then ok "the GeoIP database is already the DB-IP City Lite build"
else
  if [ "$YES" -eq 1 ] || [ -z "$TTY" ]; then a=y; else
    echo "  The database shipped with the indexer can place IPs in the wrong country (a Pakistani ISP range showed up as South Africa)."
    echo "  This replaces it with DB-IP City Lite (free, CC BY 4.0, https://db-ip.com) and restarts wazuh-indexer once (about a minute; alerts are retried)."
    read -rp "  Update the GeoIP database now? [Y/n] " a < "$TTY"; fi
  if [ "${a:-y}" = n ] || [ "${a:-y}" = N ]; then warn "skipped by choice"; else
    got=0
    for m in "$(date +%Y-%m)" "$(date -d '-1 month' +%Y-%m 2>/dev/null || date -v-1m +%Y-%m)"; do
      if curl -sfL --connect-timeout 15 -m 600 -o "$WORK/city.mmdb.gz" "https://download.db-ip.com/free/dbip-city-lite-$m.mmdb.gz"; then got=1; break; fi
    done
    if [ "$got" -ne 1 ] || ! gzip -t "$WORK/city.mmdb.gz" 2>/dev/null; then warn "could not download the DB-IP database; keeping the current one"
    else
      gunzip -f "$WORK/city.mmdb.gz"
      if [ "$(stat -c %s "$WORK/city.mmdb")" -lt 50000000 ]; then warn "the downloaded database looks too small; keeping the current one"
      elif ! python3 -I "$WORK/patch_mmdb.py" "$WORK/city.mmdb" "$WORK/city-patched.mmdb" >/dev/null; then warn "the downloaded database has an unexpected format; keeping the current one"
      else
        cp -p "$GEOIP_DB" "$GEOIP_DB.orig-$STAMP"
        OWN=$(stat -c %U:%G "$GEOIP_DB"); install -m 0640 -o "${OWN%%:*}" -g "${OWN##*:}" "$WORK/city-patched.mmdb" "$GEOIP_DB"
        systemctl restart wazuh-indexer
        if wait_indexer && [ -n "$(geo_sim 8.8.8.8)" ]; then
          ok "GeoIP database updated (backup: $GEOIP_DB.orig-$STAMP); 8.8.8.8 -> $(geo_sim 8.8.8.8)"
          echo "        IP geolocation by DB-IP (https://db-ip.com), CC BY 4.0"
        else
          warn "the indexer did not accept the new database: restoring the original"
          cp -p "$GEOIP_DB.orig-$STAMP" "$GEOIP_DB"; systemctl restart wazuh-indexer; wait_indexer || warn "wazuh-indexer is slow to come back: check 'systemctl status wazuh-indexer'"
        fi
      fi
    fi
  fi
fi

# ------------------------------------------------------------------------------------------------ wazuh
step "Installing the Wazuh rules and log source"
RULES_BAK=$(mktemp -d "$WORK/bak.XXXXXX")
[ -e "$RULES_DIR/$RULE_FILE" ] && cp -p "$RULES_DIR/$RULE_FILE" "$RULES_BAK/$RULE_FILE"
cp -p "$OSSEC_CONF" "$RULES_BAK/ossec.conf"
write_file "$RULES_DIR/$RULE_FILE" 0660 root:wazuh < "$WORK/gworkspace_rules.xml"
ok "rules 100800-100880 in $RULES_DIR/$RULE_FILE"

python3 - "$OSSEC_CONF" "$SYNC_DIR/$LOCALFILE" <<'PY'
import sys
p, loc = sys.argv[1], sys.argv[2]
s = open(p).read()
if loc in s:
    print("  localfile block already present")
else:
    add = "\n  <localfile>\n    <log_format>json</log_format>\n    <location>%s</location>\n  </localfile>\n" % loc
    i = s.rindex("</ossec_config>")
    open(p, "w").write(s[:i].rstrip("\n") + "\n" + add + "\n" + s[i:])
    print("  added the localfile block to " + p)
PY

if /var/ossec/bin/wazuh-analysisd -t >"$WORK/analysisd.log" 2>&1; then ok "Wazuh accepts the rules and ossec.conf"
else
  cat "$WORK/analysisd.log" >&2
  if [ -e "$RULES_BAK/$RULE_FILE" ]; then cp -p "$RULES_BAK/$RULE_FILE" "$RULES_DIR/$RULE_FILE"; else rm -f "$RULES_DIR/$RULE_FILE"; fi
  cp -p "$RULES_BAK/ossec.conf" "$OSSEC_CONF"
  die "Wazuh rejected the configuration; the rules and ossec.conf were put back as they were (the sync service is installed but not started)"
fi

if [ "$YES" -eq 1 ] || [ -z "$TTY" ]; then a=y; else read -rp "Restart wazuh-manager now (needed to load the rules and the log source)? [Y/n] " a < "$TTY"; fi
if [ "${a:-y}" != n ] && [ "${a:-y}" != N ]; then systemctl restart wazuh-manager && ok "wazuh-manager restarted"
else warn "not restarted: run 'systemctl restart wazuh-manager' before the events can be rated"; fi

# ------------------------------------------------------------------------------------------------ start
step "Starting the sync service"
systemctl daemon-reload
systemctl enable gworkspace-sync >/dev/null 2>&1 || true
systemctl restart gworkspace-sync
sleep 3
systemctl is-active --quiet gworkspace-sync && ok "gworkspace-sync is running" || { journalctl -u gworkspace-sync -n 20 --no-pager >&2; die "gworkspace-sync did not start"; }

step "Waiting for the first events to reach wazuh-alerts-* (up to 6 minutes)"
IXQ() { ix -m 30 -X POST -H 'Content-Type: application/json' "$INDEXER_URL/wazuh-alerts-*/_search?ignore_unavailable=true" -d "$1" 2>/dev/null || echo '{}'; }
EV_Q='{"term":{"data.type":"gws_activity"}}'
count_events() { IXQ '{"size":0,"track_total_hits":true,"query":{"bool":{"filter":[{"term":{"data.integration":"google-workspace"}},'"$EV_Q"']}}}' \
  | python3 -c 'import json,sys
try: print(json.load(sys.stdin)["hits"]["total"]["value"])
except Exception: print(0)'; }
n=0; for i in $(seq 1 36); do
  n=$(count_events)
  [ "${n:-0}" -gt 0 ] 2>/dev/null && break
  printf '.'; sleep 10
done; echo
cat > "$WORK/report.py" <<'__EOF_report__'
import json, sys
ev, hb = json.load(open(sys.argv[1])), json.load(open(sys.argv[2]))
tot = ev["hits"]["total"]["value"]
ag = ev.get("aggregations", {})
apps = [(b["key"], b["doc_count"]) for b in ag.get("apps", {}).get("buckets", [])]
ctry = [(b["key"], b["doc_count"]) for b in ag.get("countries", {}).get("buckets", [])]
withip = ag.get("withip", {}).get("doc_count", 0); withgeo = ag.get("withgeo", {}).get("doc_count", 0)
print("  Google Workspace events in wazuh-alerts-*: %d" % tot)
print("  by application : " + ", ".join("%s=%d" % a for a in apps))
print("  with source IP : %d   with country: %d   countries: %s" % (withip, withgeo, ", ".join("%s=%d" % c for c in ctry) or "none"))
h = hb["hits"]["hits"]
if h:
    s = h[0]["_source"].get("data", {}).get("sync", {})
    print("  sync heartbeat : status=%s new=%s requests=%s failed_apps=%s (%s)" % (s.get("status"), s.get("new_events"), s.get("requests"), s.get("failed_apps"), h[0]["_source"].get("timestamp", "")[:19]))
print("  newest events  :")
for x in ev["hits"]["hits"]:
    d = x["_source"].get("data", {}).get("gws", {})
    g = x["_source"].get("GeoLocation", {})
    print("    %s  %-12s %-28s %-34s %-18s %s" % (x["_source"].get("timestamp", "")[:19], d.get("application", ""), d.get("event_name", "")[:28],
          (d.get("actor", {}) or {}).get("email", "")[:34], d.get("ip_address", "")[:18], g.get("country_name", "")))
# exit code: 0 events found, 3 events but IPs without countries
sys.exit(3 if withip and not withgeo else 0)
__EOF_report__
RESULT=fail
if [ "${n:-0}" -gt 0 ] 2>/dev/null; then
  IXQ '{"size":5,"sort":[{"timestamp":"desc"}],"track_total_hits":true,"_source":["timestamp","data.gws.application","data.gws.event_name","data.gws.actor.email","data.gws.ip_address","GeoLocation.country_name"],"query":{"bool":{"filter":[{"term":{"data.integration":"google-workspace"}},'"$EV_Q"']}},"aggs":{"apps":{"terms":{"field":"data.gws.application","size":25}},"countries":{"terms":{"field":"GeoLocation.country_name","size":10}},"withip":{"filter":{"exists":{"field":"data.gws.ip_address"}}},"withgeo":{"filter":{"exists":{"field":"GeoLocation.country_name"}}}}}' > "$WORK/ev.json"
  IXQ '{"size":1,"sort":[{"timestamp":"desc"}],"query":{"bool":{"filter":[{"term":{"data.integration":"google-workspace"}},{"term":{"data.type":"athena_gws_sync_heartbeat"}}]}}}' > "$WORK/hb.json"
  python3 "$WORK/report.py" "$WORK/ev.json" "$WORK/hb.json" && rc=0 || rc=$?
  if [ "$rc" -eq 0 ]; then RESULT=pass; ok "Google Workspace events are in the indexer, with countries"
  elif [ "$rc" -eq 3 ]; then RESULT=nogeo; warn "events are in the indexer but none has a country yet. IPs are geolocated by the indexer's pipeline: check that Filebeat's wazuh pipeline is loaded (filebeat setup --pipelines) and that the GeoIP step above succeeded"
  else warn "events are in the indexer, but the summary could not be read"; RESULT=pass; fi
else
  warn "no Google Workspace events in wazuh-alerts-* after 6 minutes. Diagnosis:"
  echo "        service        : $(systemctl is-active gworkspace-sync)"
  echo "        buffer lines   : $(wc -l < "$SYNC_DIR/$LOCALFILE" 2>/dev/null || echo 'file missing')  ($SYNC_DIR/$LOCALFILE)"
  echo "        logcollector   : $(grep -c "$SYNC_DIR/$LOCALFILE" /var/ossec/logs/ossec.log 2>/dev/null || echo 0) ossec.log line(s) mention the file"
  echo "        alerts.json    : $(grep -c '"integration":"google-workspace"' /var/ossec/logs/alerts/alerts.json 2>/dev/null || echo 0) google-workspace alert(s) written by the manager"
  echo "        last journal   :"; journalctl -u gworkspace-sync -n 6 --no-pager 2>/dev/null | cut -c1-200 | sed 's/^/          /'
  echo "        (no alerts.json hits = the manager is not rating the file; alerts there but not in the indexer = Filebeat/indexer problem)"
fi

cat <<EOF

${B}Done.${N}  result: ${RESULT}
  Service        systemctl status gworkspace-sync     journalctl -u gworkspace-sync -f
  Settings       $ENV_DIR/env  (then: systemctl restart gworkspace-sync)
  Certificate    $CERT_DIR  (client.crt, client.key, ca.crt, certificate_config.json, wif-credential-config.json)
  Rules          $RULES_DIR/$RULE_FILE  (100800-100880)
  Data buffer    $SYNC_DIR/$LOCALFILE  (rotated daily; real data lives in wazuh-alerts-*)
The first run back-fills the last 168 hours; the Reports API can lag events by minutes to a few hours.
This installer contains the client private key: delete it from this host once you are done (shred -u install-gworkspace-sync.sh).
EOF
[ "$RESULT" = fail ] && exit 1
exit 0
